/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Sidebar } from './components/Sidebar';
import { Header } from './components/Header';
import { DashboardOverview } from './components/DashboardOverview';
import { VendorDirectory } from './components/VendorDirectory';
import { VendorDetailModal } from './components/VendorDetailModal';
import { QuestionnaireViewer } from './components/QuestionnaireViewer';
import { QuestionnairesHub } from './components/QuestionnairesHub';
import { ContinuousMonitoring } from './components/ContinuousMonitoring';
import { ConcentrationRisk } from './components/ConcentrationRisk';
import { RemediationTracker } from './components/RemediationTracker';
import { RegulatoryReporting } from './components/RegulatoryReporting';
import { AddVendorModal } from './components/AddVendorModal';

import { 
  Vendor, 
  MonitoringAlert, 
  Finding, 
  InstitutionProfile, 
  VendorQuestionnaire, 
  Question 
} from './types/tprm';
import { 
  mockVendors, 
  initialAlerts, 
  initialFindings, 
  initialInstitution 
} from './data/mockVendors';
import { CheckCircle2 } from 'lucide-react';

export default function App() {
  const [currentTab, setCurrentTab] = useState<string>('dashboard');
  const [vendors, setVendors] = useState<Vendor[]>(() => {
    const saved = localStorage.getItem('vigil_tprm_vendors');
    return saved ? JSON.parse(saved) : mockVendors;
  });

  const [alerts, setAlerts] = useState<MonitoringAlert[]>(() => {
    const saved = localStorage.getItem('vigil_tprm_alerts');
    return saved ? JSON.parse(saved) : initialAlerts;
  });

  const [findings, setFindings] = useState<Finding[]>(() => {
    const saved = localStorage.getItem('vigil_tprm_findings');
    return saved ? JSON.parse(saved) : initialFindings;
  });

  const [institution, setInstitution] = useState<InstitutionProfile>(initialInstitution);

  // Selected item states
  const [selectedVendor, setSelectedVendor] = useState<Vendor | null>(null);
  const [activeQuestionnaire, setActiveQuestionnaire] = useState<VendorQuestionnaire | null>(null);
  const [showAddVendorModal, setShowAddVendorModal] = useState(false);
  const [isScanning, setIsScanning] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Save changes to localStorage
  useEffect(() => {
    localStorage.setItem('vigil_tprm_vendors', JSON.stringify(vendors));
  }, [vendors]);

  useEffect(() => {
    localStorage.setItem('vigil_tprm_alerts', JSON.stringify(alerts));
  }, [alerts]);

  useEffect(() => {
    localStorage.setItem('vigil_tprm_findings', JSON.stringify(findings));
  }, [findings]);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  // Add new vendor
  const handleAddVendor = (newVendor: Vendor) => {
    setVendors(prev => [newVendor, ...prev]);
    showToast(`Successfully onboarded ${newVendor.name} (${newVendor.tier}). Initial assessment dispatched.`);
  };

  // Resolve finding
  const handleResolveFinding = (findingId: string) => {
    setFindings(prev => prev.map(f => {
      if (f.id === findingId) {
        return { ...f, status: 'Resolved' };
      }
      return f;
    }));

    // If finding belongs to a vendor, update active findings count
    setVendors(prev => prev.map(v => {
      return {
        ...v,
        activeFindingsCount: {
          ...v.activeFindingsCount,
          critical: Math.max(0, v.activeFindingsCount.critical - 1)
        },
        residualRiskScore: Math.max(3, v.residualRiskScore - 3)
      };
    }));

    showToast('Deficiency resolved and verified by Third-Party Risk Officer.');
  };

  // Accept risk with justification
  const handleAcceptRisk = (findingId: string, justification: string) => {
    setFindings(prev => prev.map(f => {
      if (f.id === findingId) {
        return { 
          ...f, 
          status: 'Accepted Risk',
          compensatingControl: justification || 'Formally approved business exception signed off by CISO.'
        };
      }
      return f;
    }));
    showToast('Risk acceptance approved and logged to OCC Audit Register.');
  };

  // Acknowledge alert
  const handleAcknowledgeAlert = (alertId: string) => {
    setAlerts(prev => prev.map(a => {
      if (a.id === alertId) {
        return { ...a, status: 'Investigating' };
      }
      return a;
    }));
    showToast('Alert acknowledged. Supervisory investigation ticket opened.');
  };

  // Request remediation from alert
  const handleRequestRemediationFromAlert = (alert: MonitoringAlert) => {
    const newFinding: Finding = {
      id: `fnd-${Date.now().toString().slice(-3)}`,
      vendorId: alert.vendorId,
      vendorName: alert.vendorName,
      title: alert.title,
      description: alert.detail,
      severity: alert.severity === 'Critical' ? 'Critical' : 'High',
      status: 'Open',
      source: 'Continuous Monitoring',
      identifiedDate: new Date().toISOString().split('T')[0],
      dueDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      slaDaysRemaining: 30,
      assignedTo: 'Lead TPRM Officer',
      remediationPlan: 'Request immediate patch or configuration fix from vendor CISO.'
    };

    setFindings(prev => [newFinding, ...prev]);
    showToast(`Corrective Action Plan deficiency raised for ${alert.vendorName}.`);
  };

  // Raise finding from question
  const handleRaiseFindingFromQuestion = (q: Question, vendorName: string, vendorId: string) => {
    const newFinding: Finding = {
      id: `fnd-${Date.now().toString().slice(-3)}`,
      vendorId,
      vendorName,
      title: `${q.code}: Control Deficiency Identified in ${q.domain}`,
      description: `Vendor response (${q.response || 'Unanswered'}) fell short of required assurance standard: ${q.question}`,
      severity: q.weight >= 4 ? 'High' : 'Medium',
      status: 'Open',
      source: 'SIG Assessment',
      identifiedDate: new Date().toISOString().split('T')[0],
      dueDate: new Date(Date.now() + 45 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      slaDaysRemaining: 45,
      assignedTo: 'Compliance Governance Lead',
      remediationPlan: 'Vendor required to submit remediation roadmap or provide evidence of compensating controls.'
    };

    setFindings(prev => [newFinding, ...prev]);
    showToast(`Logged new deficiency from questionnaire control ${q.code}.`);
  };

  // Save questionnaire
  const handleSaveQuestionnaire = (updated: VendorQuestionnaire) => {
    setActiveQuestionnaire(updated);
    setVendors(prev => prev.map(v => {
      if (v.id === updated.vendorId) {
        return {
          ...v,
          questionnaires: v.questionnaires.map(q => q.id === updated.id ? updated : q),
          securityScore: Math.round((v.securityScore + updated.overallScore) / 2)
        };
      }
      return v;
    }));
    showToast('Questionnaire changes saved and fleet assurance scores recalibrated.');
  };

  // Launch new questionnaire for a vendor
  const handleLaunchNewQuestionnaire = (vendorId: string, standard: string) => {
    const vendor = vendors.find(v => v.id === vendorId);
    if (!vendor) return;

    const newQ: VendorQuestionnaire = {
      id: `q-${Date.now()}`,
      vendorId,
      vendorName: vendor.name,
      title: `Ad-hoc ${standard} Assessment`,
      standard: standard as any,
      status: 'Sent to Vendor',
      completionRate: 0,
      overallScore: 0,
      dueDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      lastUpdated: new Date().toISOString().split('T')[0],
      sections: mockVendors[0].questionnaires[0]?.sections || []
    };

    setVendors(prev => prev.map(v => {
      if (v.id === vendorId) {
        return {
          ...v,
          questionnaires: [newQ, ...v.questionnaires]
        };
      }
      return v;
    }));

    showToast(`Dispatched new ${standard} assessment to ${vendor.name}.`);
  };

  // Run fleet telemetry scan simulation
  const handleRunTelemetryScan = () => {
    setIsScanning(true);
    setTimeout(() => {
      setIsScanning(false);
      showToast('Continuous attack surface scan complete: 1,420 endpoints & 42 certificates verified.');
    }, 2000);
  };

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-slate-950 font-sans text-slate-100">
      {/* Toast Notification Container */}
      {toastMessage && (
        <div className="fixed top-5 right-5 z-60 bg-slate-900 border border-cyan-500 text-cyan-200 px-4 py-3 rounded-xl shadow-2xl flex items-center gap-2.5 text-xs animate-in fade-in duration-200">
          <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0" />
          <span className="font-medium">{toastMessage}</span>
        </div>
      )}

      {/* Sidebar Navigation */}
      <Sidebar
        currentTab={currentTab}
        setCurrentTab={(tab) => {
          setActiveQuestionnaire(null);
          setCurrentTab(tab);
        }}
        institution={institution}
        activeAlertsCount={alerts.filter(a => a.severity === 'Critical' || a.severity === 'High').length}
        openFindingsCount={findings.filter(f => f.status !== 'Resolved').length}
      />

      {/* Main App Container */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Top Header */}
        <Header
          currentTab={activeQuestionnaire ? 'questionnaires' : currentTab}
          onOpenAddVendor={() => setShowAddVendorModal(true)}
          onExportAuditReport={() => setCurrentTab('reports')}
          onRunTelemetryScan={handleRunTelemetryScan}
          isScanning={isScanning}
        />

        {/* Viewport Content */}
        <main className="flex-1 overflow-y-auto">
          {activeQuestionnaire ? (
            <QuestionnaireViewer
              questionnaire={activeQuestionnaire}
              onBack={() => setActiveQuestionnaire(null)}
              onSaveQuestionnaire={handleSaveQuestionnaire}
              onRaiseFindingFromQuestion={handleRaiseFindingFromQuestion}
            />
          ) : (
            <>
              {currentTab === 'dashboard' && (
                <DashboardOverview
                  vendors={vendors}
                  alerts={alerts}
                  findings={findings}
                  institution={institution}
                  onSelectVendor={(v) => setSelectedVendor(v)}
                  onNavigateTab={(tab) => setCurrentTab(tab)}
                  onAcknowledgeAlert={handleAcknowledgeAlert}
                />
              )}

              {currentTab === 'vendors' && (
                <VendorDirectory
                  vendors={vendors}
                  onSelectVendor={(v) => setSelectedVendor(v)}
                  onOpenAddVendor={() => setShowAddVendorModal(true)}
                />
              )}

              {currentTab === 'questionnaires' && (
                <QuestionnairesHub
                  vendors={vendors}
                  onOpenQuestionnaire={(q) => setActiveQuestionnaire(q)}
                  onOpenAddVendor={() => setShowAddVendorModal(true)}
                />
              )}

              {currentTab === 'monitoring' && (
                <ContinuousMonitoring
                  alerts={alerts}
                  vendors={vendors}
                  onAcknowledgeAlert={handleAcknowledgeAlert}
                  onRequestRemediation={handleRequestRemediationFromAlert}
                  onRunTelemetryScan={handleRunTelemetryScan}
                  isScanning={isScanning}
                />
              )}

              {currentTab === 'concentration' && (
                <ConcentrationRisk
                  vendors={vendors}
                  onSelectVendor={(v) => setSelectedVendor(v)}
                />
              )}

              {currentTab === 'remediation' && (
                <RemediationTracker
                  findings={findings}
                  onResolveFinding={handleResolveFinding}
                  onAcceptRisk={handleAcceptRisk}
                />
              )}

              {currentTab === 'reports' && (
                <RegulatoryReporting
                  vendors={vendors}
                  findings={findings}
                  institution={institution}
                />
              )}
            </>
          )}
        </main>
      </div>

      {/* Vendor Detail 360 Modal */}
      {selectedVendor && (
        <VendorDetailModal
          vendor={selectedVendor}
          onClose={() => setSelectedVendor(null)}
          onOpenQuestionnaire={(q) => {
            setSelectedVendor(null);
            setActiveQuestionnaire(q);
          }}
          onResolveFinding={handleResolveFinding}
          onLaunchNewQuestionnaire={handleLaunchNewQuestionnaire}
        />
      )}

      {/* Onboard New Vendor Modal */}
      {showAddVendorModal && (
        <AddVendorModal
          onClose={() => setShowAddVendorModal(false)}
          onAddVendor={handleAddVendor}
        />
      )}
    </div>
  );
}
