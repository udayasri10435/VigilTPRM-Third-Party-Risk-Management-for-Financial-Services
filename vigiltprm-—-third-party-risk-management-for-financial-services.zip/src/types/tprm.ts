export type RiskTier = 'Tier 1' | 'Tier 2' | 'Tier 3';

export type VendorStatus = 'Active' | 'Under Review' | 'Onboarding' | 'Conditional' | 'Offboarding';

export type CriticalityLevel = 'Mission Critical' | 'High' | 'Medium' | 'Low';

export type RegulatoryFramework = 'OCC 2023-29' | 'DORA' | 'EBA Guidelines' | 'NYDFS 500' | 'PCI-DSS v4' | 'SOC 2 Type II' | 'ISO 27001';

export type DataClassification = 'NPI / PII' | 'Cardholder Data (CHD)' | 'Confidential IP' | 'Operational Data' | 'Public';

export interface SecurityVectorScores {
  networkSecurity: number; // 0 - 100
  patchCadence: number;
  applicationSecurity: number;
  dnsEmailHygiene: number;
  darkWebExposure: number;
  endpointHygiene: number;
  complianceAttestation: number;
}

export interface FourthPartyDependency {
  name: string;
  category: 'Cloud Infrastructure' | 'Identity / IAM' | 'CDN / DDoS' | 'Database' | 'Payment Rail' | 'SaaS Gateway';
  provider: string;
  region: string;
  riskLevel: 'High' | 'Medium' | 'Low';
  notes: string;
}

export interface Finding {
  id: string;
  vendorId: string;
  vendorName: string;
  title: string;
  description: string;
  severity: 'Critical' | 'High' | 'Medium' | 'Low';
  status: 'Open' | 'In Remediation' | 'Under Review' | 'Accepted Risk' | 'Resolved';
  source: 'SIG Assessment' | 'Continuous Monitoring' | 'SOC 2 Review' | 'Penetration Test';
  identifiedDate: string;
  dueDate: string;
  remediationPlan?: string;
  slaDaysRemaining: number;
  compensatingControl?: string;
  assignedTo: string;
}

export interface SecurityDocument {
  id: string;
  name: string;
  type: 'SOC 2 Type II' | 'ISO 27001' | 'Penetration Test Report' | 'BCP / DR Summary' | 'Bridge Letter' | 'PCI AoC';
  periodStart: string;
  periodEnd: string;
  status: 'Valid' | 'Expiring Soon' | 'Expired' | 'Pending Review';
  auditor: string;
  fileSize: string;
  qualifiedOpinion: boolean; // false = clean opinion, true = qualified/exceptions noted
  exceptionsNoted?: string;
}

export interface Question {
  id: string;
  code: string;
  domain: string;
  question: string;
  guidance: string;
  weight: number; // 1 to 5
  response?: 'Yes' | 'Partial' | 'No' | 'Not Applicable';
  vendorComments?: string;
  reviewerScore?: number; // 0 - 100
  reviewerNotes?: string;
  evidenceRequired: boolean;
  evidenceAttached?: string;
  findingRaised?: boolean;
}

export interface QuestionnaireSection {
  id: string;
  title: string;
  domain: string;
  weightPercentage: number;
  questions: Question[];
}

export interface VendorQuestionnaire {
  id: string;
  vendorId: string;
  vendorName: string;
  title: string;
  standard: 'SIG Complete' | 'SIG Lite' | 'CSA CAIQ v4' | 'DORA ICT Third-Party' | 'Financial Services Cloud Assessment';
  status: 'Draft' | 'Sent to Vendor' | 'In Progress' | 'Submitted' | 'Under Review' | 'Completed';
  completionRate: number; // 0 - 100
  overallScore: number; // 0 - 100
  dueDate: string;
  lastUpdated: string;
  sections: QuestionnaireSection[];
}

export interface MonitoringAlert {
  id: string;
  vendorId: string;
  vendorName: string;
  tier: RiskTier;
  timestamp: string;
  severity: 'Critical' | 'High' | 'Medium' | 'Low' | 'Info';
  category: 'Vulnerability' | 'Certificate' | 'Email Hygiene' | 'Breach / Dark Web' | 'Regulatory' | 'Contractual';
  title: string;
  detail: string;
  impactScoreChange: number; // e.g. -5 points
  status: 'New' | 'Investigating' | 'Remediation Requested' | 'Suppressed';
  targetAsset?: string;
}

export interface Vendor {
  id: string;
  name: string;
  domain: string;
  tier: RiskTier;
  status: VendorStatus;
  criticality: CriticalityLevel;
  primaryCategory: string;
  businessOwner: string;
  tprAnalyst: string;
  annualSpendUsd: number;
  contractRenewalDate: string;
  contractStartDate: string;
  hostingLocation: string;
  dataClassifications: DataClassification[];
  applicableFrameworks: RegulatoryFramework[];
  
  // Scoring
  securityScore: number; // 0 - 100
  scoreGrade: 'A' | 'B' | 'C' | 'D' | 'F';
  creditStyleScore: number; // 300 - 850
  scoreTrend30d: number; // +3, -8, etc.
  inherentRiskScore: number; // 1 - 25 (Impact x Likelihood)
  residualRiskScore: number; // 1 - 25 (Post-control)
  vectorScores: SecurityVectorScores;
  
  // Relational aggregates
  activeFindingsCount: {
    critical: number;
    high: number;
    medium: number;
    low: number;
  };
  questionnaires: VendorQuestionnaire[];
  documents: SecurityDocument[];
  fourthParties: FourthPartyDependency[];
  recentAlerts: MonitoringAlert[];
  description: string;
  contactEmail: string;
}

export interface InstitutionProfile {
  name: string;
  charterType: string;
  regulators: string[];
  totalVendors: number;
  tier1Count: number;
  averageResidualRisk: number;
  openCriticalFindings: number;
}
