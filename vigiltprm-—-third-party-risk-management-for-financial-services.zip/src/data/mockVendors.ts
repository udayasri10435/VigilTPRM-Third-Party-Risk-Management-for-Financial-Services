import { Vendor, InstitutionProfile, MonitoringAlert, Finding } from '../types/tprm';
import { standardSigLiteSections, doraIctSections } from './questionnaires';

export const initialInstitution: InstitutionProfile = {
  name: 'First Meridian Financial Bancorp',
  charterType: 'National Commercial Bank & Asset Management',
  regulators: ['OCC', 'Federal Reserve (FRB)', 'FDIC', 'NYDFS', 'FINRA'],
  totalVendors: 42,
  tier1Count: 8,
  averageResidualRisk: 8.4,
  openCriticalFindings: 3
};

export const initialAlerts: MonitoringAlert[] = [
  {
    id: 'alt-001',
    vendorId: 'ven-002',
    vendorName: 'Aegis Core Banking Systems',
    tier: 'Tier 1',
    timestamp: '2 hours ago',
    severity: 'Critical',
    category: 'Vulnerability',
    title: 'Zero-Day CVE-2024-3400 In Perimeter Gateway',
    detail: 'External vulnerability scan detected unpatched Palo Alto GlobalProtect SSL VPN exposed on vpn.aegiscore.com. CVSS 10.0 exploit in the wild.',
    impactScoreChange: -12,
    status: 'New',
    targetAsset: 'vpn.aegiscore.com:443'
  },
  {
    id: 'alt-002',
    vendorId: 'ven-003',
    vendorName: 'Apex Data Cloud & Analytics',
    tier: 'Tier 1',
    timestamp: '7 hours ago',
    severity: 'High',
    category: 'Certificate',
    title: 'Expiring TLS Certificate (3 Days Remaining)',
    detail: 'Certificate for api-gateway.prod.apexcloud.net expires on Oct 01, 2026. Auto-renewal failure reported via OCSP status check.',
    impactScoreChange: -4,
    status: 'Investigating',
    targetAsset: 'api-gateway.prod.apexcloud.net'
  },
  {
    id: 'alt-003',
    vendorId: 'ven-001',
    vendorName: 'Synapse Payments Gateway',
    tier: 'Tier 1',
    timestamp: '1 day ago',
    severity: 'Medium',
    category: 'Breach / Dark Web',
    title: '4 Corporate Email Credentials in Breach Dump',
    detail: 'Dark web threat intelligence feed flagged 4 @synapsepay.com engineer credentials from third-party developer forum leak. MFA active on all accounts.',
    impactScoreChange: -2,
    status: 'Remediation Requested',
    targetAsset: 'Identities / SSO'
  },
  {
    id: 'alt-004',
    vendorId: 'ven-004',
    vendorName: 'Veritas Identity & Access (IAM)',
    tier: 'Tier 1',
    timestamp: '2 days ago',
    severity: 'Low',
    category: 'Email Hygiene',
    title: 'DMARC Policy Modified to None',
    detail: 'DNS record for veritas-iam.com shifted from p=reject to p=none, temporarily weakening anti-spoofing protections during mail relay migration.',
    impactScoreChange: -3,
    status: 'Remediation Requested',
    targetAsset: '_dmarc.veritas-iam.com'
  },
  {
    id: 'alt-005',
    vendorId: 'ven-005',
    vendorName: 'Sentinel AML & Sanctions Radar',
    tier: 'Tier 2',
    timestamp: '3 days ago',
    severity: 'Medium',
    category: 'Regulatory',
    title: 'DORA Sub-processor Location Change',
    detail: 'Sentinel notified customers of secondary failover telemetry migration from Frankfurt (eu-central-1) to Zurich private colocation.',
    impactScoreChange: 0,
    status: 'New',
    targetAsset: 'Compliance Registry'
  }
];

export const initialFindings: Finding[] = [
  {
    id: 'fnd-101',
    vendorId: 'ven-002',
    vendorName: 'Aegis Core Banking Systems',
    title: 'Unpatched Critical CVE on Perimeter Gateway (CVSS 10.0)',
    description: 'Active perimeter scanning identified unpatched gateway software vulnerable to unauthenticated remote code execution.',
    severity: 'Critical',
    status: 'Open',
    source: 'Continuous Monitoring',
    identifiedDate: '2026-09-28',
    dueDate: '2026-10-01',
    slaDaysRemaining: 2,
    assignedTo: 'Marcus Vance (Vendor CISO)',
    compensatingControl: 'WAF virtual patching rule active on Cloudflare perimeter',
    remediationPlan: 'Deploy vendor hotfix firmware HF-9844 during maintenance window tonight at 02:00 UTC.'
  },
  {
    id: 'fnd-102',
    vendorId: 'ven-001',
    vendorName: 'Synapse Payments Gateway',
    title: 'Delayed Access De-provisioning Audit Exceptions',
    description: 'SIG assessment verification revealed 2 former employees retained SSO access for 72 hours post-termination.',
    severity: 'High',
    status: 'In Remediation',
    source: 'SIG Assessment',
    identifiedDate: '2026-09-15',
    dueDate: '2026-10-15',
    slaDaysRemaining: 17,
    assignedTo: 'Sarah Jenkins (Compliance Lead)',
    compensatingControl: 'MFA tokens revoked immediately upon HR ticket creation',
    remediationPlan: 'Implement automated SCIM de-provisioning trigger between Workday HRIS and Okta directory.'
  },
  {
    id: 'fnd-103',
    vendorId: 'ven-004',
    vendorName: 'Veritas Identity & Access (IAM)',
    title: 'SOC 2 Type II Bridge Letter Required',
    description: 'Current SOC 2 Type II audit report period concluded on June 30, 2026 (> 90 days ago). Formal management bridge letter overdue.',
    severity: 'Medium',
    status: 'Open',
    source: 'SOC 2 Review',
    identifiedDate: '2026-09-20',
    dueDate: '2026-10-05',
    slaDaysRemaining: 7,
    assignedTo: 'Compliance Governance Office',
    remediationPlan: 'Request interim bridge letter attesting no material control changes through September 2026.'
  },
  {
    id: 'fnd-104',
    vendorId: 'ven-003',
    vendorName: 'Apex Data Cloud & Analytics',
    title: 'Subcontractor Assurances Lacking Formal SOC 2 Verification',
    description: 'Apex utilizes secondary ML telemetry partners without enforcing mandatory annual independent audit attestation.',
    severity: 'Medium',
    status: 'Under Review',
    source: 'SIG Assessment',
    identifiedDate: '2026-09-10',
    dueDate: '2026-10-20',
    slaDaysRemaining: 22,
    assignedTo: 'Vendor Management Office',
    compensatingControl: 'Data processed by secondary ML partners is pseudonymized before transmission',
    remediationPlan: 'Amend standard supplier contract terms to require SOC 2 Type II or ISO 27001 by Q1 2027.'
  }
];

export const mockVendors: Vendor[] = [
  {
    id: 'ven-001',
    name: 'Synapse Payments Gateway',
    domain: 'synapsepay.com',
    tier: 'Tier 1',
    status: 'Active',
    criticality: 'Mission Critical',
    primaryCategory: 'Payment Processing & Clearing',
    businessOwner: 'Evelyn Reed (VP Digital Payments)',
    tprAnalyst: 'Devon Cross (Senior TPRM Analyst)',
    annualSpendUsd: 4850000,
    contractRenewalDate: '2027-04-15',
    contractStartDate: '2023-04-15',
    hostingLocation: 'AWS US-East (N. Virginia)',
    dataClassifications: ['Cardholder Data (CHD)', 'NPI / PII', 'Operational Data'],
    applicableFrameworks: ['OCC 2023-29', 'PCI-DSS v4', 'NYDFS 500', 'SOC 2 Type II'],
    securityScore: 88,
    scoreGrade: 'B',
    creditStyleScore: 785,
    scoreTrend30d: -2,
    inherentRiskScore: 23, // 5 Impact x 4.6 Likelihood
    residualRiskScore: 7,  // post-controls
    vectorScores: {
      networkSecurity: 92,
      patchCadence: 86,
      applicationSecurity: 91,
      dnsEmailHygiene: 94,
      darkWebExposure: 78,
      endpointHygiene: 88,
      complianceAttestation: 90
    },
    activeFindingsCount: { critical: 0, high: 1, medium: 1, low: 0 },
    questionnaires: [
      {
        id: 'q-synapse-01',
        vendorId: 'ven-001',
        vendorName: 'Synapse Payments Gateway',
        title: '2026 Annual Comprehensive SIG Lite Assessment',
        standard: 'SIG Lite',
        status: 'Completed',
        completionRate: 100,
        overallScore: 89,
        dueDate: '2026-09-01',
        lastUpdated: '2026-09-18',
        sections: JSON.parse(JSON.stringify(standardSigLiteSections))
      }
    ],
    documents: [
      {
        id: 'doc-syn-01',
        name: 'Synapse_SOC2_TypeII_Report_2025.pdf',
        type: 'SOC 2 Type II',
        periodStart: '2024-10-01',
        periodEnd: '2025-09-30',
        status: 'Valid',
        auditor: 'PricewaterhouseCoopers (PwC)',
        fileSize: '3.8 MB',
        qualifiedOpinion: false
      },
      {
        id: 'doc-syn-02',
        name: 'PCI_DSS_v4_Attestation_of_Compliance.pdf',
        type: 'PCI AoC',
        periodStart: '2025-03-01',
        periodEnd: '2026-03-01',
        status: 'Valid',
        auditor: 'Coalfire Systems QSA',
        fileSize: '1.2 MB',
        qualifiedOpinion: false
      },
      {
        id: 'doc-syn-03',
        name: 'Annual_Penetration_Test_Executive_Summary_2025.pdf',
        type: 'Penetration Test Report',
        periodStart: '2025-08-15',
        periodEnd: '2025-09-15',
        status: 'Valid',
        auditor: 'Bishop Fox',
        fileSize: '890 KB',
        qualifiedOpinion: false
      }
    ],
    fourthParties: [
      {
        name: 'Amazon Web Services (AWS)',
        category: 'Cloud Infrastructure',
        provider: 'AWS us-east-1 / us-west-2',
        region: 'United States',
        riskLevel: 'High',
        notes: 'Hosts primary transaction processing engine and KMS key stores.'
      },
      {
        name: 'Cloudflare',
        category: 'CDN / DDoS',
        provider: 'Cloudflare Enterprise',
        region: 'Global Anycast',
        riskLevel: 'Medium',
        notes: 'WAF, DDoS mitigation, and API edge rate limiting.'
      },
      {
        name: 'Okta Identity Cloud',
        category: 'Identity / IAM',
        provider: 'Okta Enterprise',
        region: 'US Cloud',
        riskLevel: 'High',
        notes: 'Administrative workforce identity and customer dashboard SSO.'
      }
    ],
    recentAlerts: [initialAlerts[2]],
    description: 'Primary real-time payment gateway facilitating automated clearing house (ACH), wire rails, and card processing for retail and commercial accounts.',
    contactEmail: 'security-assurance@synapsepay.com'
  },
  {
    id: 'ven-002',
    name: 'Aegis Core Banking Systems',
    domain: 'aegiscore.com',
    tier: 'Tier 1',
    status: 'Conditional',
    criticality: 'Mission Critical',
    primaryCategory: 'Core Account & Ledger Ledger Engine',
    businessOwner: 'Jonathan Hayes (Chief Operating Officer)',
    tprAnalyst: 'Devon Cross (Senior TPRM Analyst)',
    annualSpendUsd: 14200000,
    contractRenewalDate: '2028-12-31',
    contractStartDate: '2020-01-01',
    hostingLocation: 'Equinix Secaucus NJ & Ashburn VA (Colo) + AWS DirectConnect',
    dataClassifications: ['NPI / PII', 'Cardholder Data (CHD)', 'Confidential IP', 'Operational Data'],
    applicableFrameworks: ['OCC 2023-29', 'DORA', 'EBA Guidelines', 'NYDFS 500', 'SOC 2 Type II'],
    securityScore: 68,
    scoreGrade: 'D',
    creditStyleScore: 615,
    scoreTrend30d: -14,
    inherentRiskScore: 25, // 5 Impact x 5 Likelihood
    residualRiskScore: 16, // elevated due to critical finding
    vectorScores: {
      networkSecurity: 58,
      patchCadence: 62,
      applicationSecurity: 72,
      dnsEmailHygiene: 84,
      darkWebExposure: 65,
      endpointHygiene: 74,
      complianceAttestation: 80
    },
    activeFindingsCount: { critical: 1, high: 0, medium: 0, low: 0 },
    questionnaires: [
      {
        id: 'q-aegis-01',
        vendorId: 'ven-002',
        vendorName: 'Aegis Core Banking Systems',
        title: 'OCC Interagency Comprehensive Assessment',
        standard: 'SIG Complete',
        status: 'Under Review',
        completionRate: 94,
        overallScore: 72,
        dueDate: '2026-09-30',
        lastUpdated: '2026-09-27',
        sections: JSON.parse(JSON.stringify(standardSigLiteSections))
      }
    ],
    documents: [
      {
        id: 'doc-aeg-01',
        name: 'Aegis_SOC1_TypeII_SSAE18_Report.pdf',
        type: 'SOC 2 Type II',
        periodStart: '2024-11-01',
        periodEnd: '2025-10-31',
        status: 'Valid',
        auditor: 'Ernst & Young (EY)',
        fileSize: '5.2 MB',
        qualifiedOpinion: true,
        exceptionsNoted: 'Exception in change management ticketing approval sequence for 2 emergency core patches.'
      },
      {
        id: 'doc-aeg-02',
        name: 'Business_Continuity_Disaster_Recovery_Audit.pdf',
        type: 'BCP / DR Summary',
        periodStart: '2025-06-01',
        periodEnd: '2026-06-01',
        status: 'Valid',
        auditor: 'Protiviti Governance',
        fileSize: '2.1 MB',
        qualifiedOpinion: false
      }
    ],
    fourthParties: [
      {
        name: 'Equinix Data Centers',
        category: 'Cloud Infrastructure',
        provider: 'NY4 / DC11 IBX Centers',
        region: 'United States',
        riskLevel: 'High',
        notes: 'Tier IV colocation hosting primary core banking IBM Z systems.'
      },
      {
        name: 'Oracle Corporation',
        category: 'Database',
        provider: 'Oracle Exadata Cloud@Customer',
        region: 'Secaucus Private Mesh',
        riskLevel: 'High',
        notes: 'General ledger transactional database clusters.'
      },
      {
        name: 'Palo Alto Networks',
        category: 'Cloud Infrastructure',
        provider: 'GlobalProtect SSL VPN Gateway',
        region: 'Customer Edge',
        riskLevel: 'High',
        notes: 'Remote engineer management ingress point (actively under CVE remediation).'
      }
    ],
    recentAlerts: [initialAlerts[0]],
    description: 'System of record maintaining demand deposit accounts (DDA), general ledger, retail loan servicing, and interest computation for all customer branches.',
    contactEmail: 'infosec@aegiscore.com'
  },
  {
    id: 'ven-003',
    name: 'Apex Data Cloud & Analytics',
    domain: 'apexcloud.net',
    tier: 'Tier 1',
    status: 'Active',
    criticality: 'High',
    primaryCategory: 'Enterprise Data Warehouse & ML',
    businessOwner: 'Dr. Aaron Patel (Chief Analytics Officer)',
    tprAnalyst: 'Devon Cross (Senior TPRM Analyst)',
    annualSpendUsd: 3100000,
    contractRenewalDate: '2026-11-30',
    contractStartDate: '2022-11-30',
    hostingLocation: 'Google Cloud Platform (us-central1, europe-west3)',
    dataClassifications: ['NPI / PII', 'Confidential IP', 'Operational Data'],
    applicableFrameworks: ['OCC 2023-29', 'DORA', 'NYDFS 500', 'SOC 2 Type II', 'ISO 27001'],
    securityScore: 84,
    scoreGrade: 'B',
    creditStyleScore: 742,
    scoreTrend30d: -4,
    inherentRiskScore: 21,
    residualRiskScore: 9,
    vectorScores: {
      networkSecurity: 82,
      patchCadence: 88,
      applicationSecurity: 85,
      dnsEmailHygiene: 92,
      darkWebExposure: 86,
      endpointHygiene: 80,
      complianceAttestation: 89
    },
    activeFindingsCount: { critical: 0, high: 0, medium: 1, low: 0 },
    questionnaires: [
      {
        id: 'q-apex-01',
        vendorId: 'ven-003',
        vendorName: 'Apex Data Cloud & Analytics',
        title: 'CSA CAIQ v4 Cloud Security Assessment',
        standard: 'CSA CAIQ v4',
        status: 'Completed',
        completionRate: 100,
        overallScore: 86,
        dueDate: '2026-08-15',
        lastUpdated: '2026-08-20',
        sections: JSON.parse(JSON.stringify(standardSigLiteSections))
      }
    ],
    documents: [
      {
        id: 'doc-apx-01',
        name: 'Apex_ISO_27001_Certificate_2025-2028.pdf',
        type: 'ISO 27001',
        periodStart: '2025-01-15',
        periodEnd: '2028-01-14',
        status: 'Valid',
        auditor: 'BSI Group Assurance',
        fileSize: '1.4 MB',
        qualifiedOpinion: false
      },
      {
        id: 'doc-apx-02',
        name: 'Apex_SOC2_TypeII_Report_2025.pdf',
        type: 'SOC 2 Type II',
        periodStart: '2024-09-01',
        periodEnd: '2025-08-31',
        status: 'Valid',
        auditor: 'KPMG LLP',
        fileSize: '4.6 MB',
        qualifiedOpinion: false
      }
    ],
    fourthParties: [
      {
        name: 'Google Cloud Platform (GCP)',
        category: 'Cloud Infrastructure',
        provider: 'BigQuery / Vertex AI Infrastructure',
        region: 'US & EU Regions',
        riskLevel: 'High',
        notes: 'Underlying hyper-scaler hosting distributed financial risk models.'
      },
      {
        name: 'Confluent Cloud',
        category: 'Cloud Infrastructure',
        provider: 'Managed Kafka Streaming',
        region: 'AWS us-east-1 peering',
        riskLevel: 'Medium',
        notes: 'Event-streaming pipeline feeding real-time fraud models.'
      }
    ],
    recentAlerts: [initialAlerts[1]],
    description: 'Centralized financial data warehouse handling risk modeling, Basel III capital adequacy calculations, predictive customer churn analytics, and regulatory reporting extracts.',
    contactEmail: 'grc@apexcloud.net'
  },
  {
    id: 'ven-004',
    name: 'Veritas Identity & Access (IAM)',
    domain: 'veritas-iam.com',
    tier: 'Tier 1',
    status: 'Active',
    criticality: 'Mission Critical',
    primaryCategory: 'Workforce & Customer Identity Provider',
    businessOwner: 'Liam Sterling (Chief Information Security Officer)',
    tprAnalyst: 'Devon Cross (Senior TPRM Analyst)',
    annualSpendUsd: 1950000,
    contractRenewalDate: '2027-01-31',
    contractStartDate: '2024-01-31',
    hostingLocation: 'Multi-region AWS (N. Virginia, Oregon, Frankfurt)',
    dataClassifications: ['NPI / PII', 'Operational Data'],
    applicableFrameworks: ['OCC 2023-29', 'DORA', 'NYDFS 500', 'SOC 2 Type II'],
    securityScore: 92,
    scoreGrade: 'A',
    creditStyleScore: 820,
    scoreTrend30d: 3,
    inherentRiskScore: 24,
    residualRiskScore: 6,
    vectorScores: {
      networkSecurity: 96,
      patchCadence: 94,
      applicationSecurity: 95,
      dnsEmailHygiene: 88,
      darkWebExposure: 92,
      endpointHygiene: 93,
      complianceAttestation: 92
    },
    activeFindingsCount: { critical: 0, high: 0, medium: 1, low: 0 },
    questionnaires: [
      {
        id: 'q-ver-01',
        vendorId: 'ven-004',
        vendorName: 'Veritas Identity & Access (IAM)',
        title: 'DORA ICT Third-Party Regulatory Assessment',
        standard: 'DORA ICT Third-Party',
        status: 'Completed',
        completionRate: 100,
        overallScore: 94,
        dueDate: '2026-07-31',
        lastUpdated: '2026-08-04',
        sections: JSON.parse(JSON.stringify(doraIctSections))
      }
    ],
    documents: [
      {
        id: 'doc-ver-01',
        name: 'Veritas_SOC2_TypeII_Report_PeriodEnd_June2026.pdf',
        type: 'SOC 2 Type II',
        periodStart: '2025-07-01',
        periodEnd: '2026-06-30',
        status: 'Expiring Soon',
        auditor: 'Deloitte & Touche LLP',
        fileSize: '4.1 MB',
        qualifiedOpinion: false
      }
    ],
    fourthParties: [
      {
        name: 'Amazon Web Services (AWS)',
        category: 'Cloud Infrastructure',
        provider: 'Route 53 & Global Accelerator',
        region: 'Global',
        riskLevel: 'High',
        notes: 'DNS and low-latency anycast auth endpoints.'
      },
      {
        name: 'Twilio Segment & Verify',
        category: 'Identity / IAM',
        provider: 'Twilio Telephony & Verify API',
        region: 'US Cloud',
        riskLevel: 'Medium',
        notes: 'Out-of-band fallback SMS/voice telephony verification.'
      }
    ],
    recentAlerts: [initialAlerts[3]],
    description: 'Enterprise single sign-on (SSO), adaptive risk-based authentication, FIDO2 passkeys, and customer portal directory services.',
    contactEmail: 'compliance@veritas-iam.com'
  },
  {
    id: 'ven-005',
    name: 'Sentinel AML & Sanctions Radar',
    domain: 'sentinelradar.io',
    tier: 'Tier 2',
    status: 'Active',
    criticality: 'High',
    primaryCategory: 'Financial Crime & Anti-Money Laundering',
    businessOwner: 'Grace Whitmore (Head of AML Compliance)',
    tprAnalyst: 'Chloe Sanders (Risk Specialist)',
    annualSpendUsd: 875000,
    contractRenewalDate: '2026-10-31',
    contractStartDate: '2023-10-31',
    hostingLocation: 'Microsoft Azure (East US 2, West Europe)',
    dataClassifications: ['NPI / PII', 'Operational Data'],
    applicableFrameworks: ['OCC 2023-29', 'DORA', 'SOC 2 Type II'],
    securityScore: 81,
    scoreGrade: 'B',
    creditStyleScore: 725,
    scoreTrend30d: 1,
    inherentRiskScore: 18,
    residualRiskScore: 8,
    vectorScores: {
      networkSecurity: 85,
      patchCadence: 80,
      applicationSecurity: 82,
      dnsEmailHygiene: 88,
      darkWebExposure: 76,
      endpointHygiene: 84,
      complianceAttestation: 85
    },
    activeFindingsCount: { critical: 0, high: 0, medium: 0, low: 0 },
    questionnaires: [
      {
        id: 'q-sent-01',
        vendorId: 'ven-005',
        vendorName: 'Sentinel AML & Sanctions Radar',
        title: 'SIG Lite Financial Assessment',
        standard: 'SIG Lite',
        status: 'Completed',
        completionRate: 100,
        overallScore: 83,
        dueDate: '2026-05-15',
        lastUpdated: '2026-05-22',
        sections: JSON.parse(JSON.stringify(standardSigLiteSections))
      }
    ],
    documents: [
      {
        id: 'doc-sent-01',
        name: 'Sentinel_SOC2_TypeII_2025.pdf',
        type: 'SOC 2 Type II',
        periodStart: '2024-12-01',
        periodEnd: '2025-11-30',
        status: 'Valid',
        auditor: 'Grant Thornton LLP',
        fileSize: '3.4 MB',
        qualifiedOpinion: false
      }
    ],
    fourthParties: [
      {
        name: 'Microsoft Azure',
        category: 'Cloud Infrastructure',
        provider: 'Azure East US 2',
        region: 'United States',
        riskLevel: 'High',
        notes: 'Hosts real-time OFAC and PEP screening algorithms.'
      }
    ],
    recentAlerts: [initialAlerts[4]],
    description: 'Real-time sanctions screening, PEP list validation, transaction monitoring rules engine, and suspicious activity report (SAR) generation pipeline.',
    contactEmail: 'security@sentinelradar.io'
  },
  {
    id: 'ven-006',
    name: 'Kallisto Enterprise CRM',
    domain: 'kallistocrm.com',
    tier: 'Tier 2',
    status: 'Active',
    criticality: 'Medium',
    primaryCategory: 'Client Relationship & Wealth Advisory',
    businessOwner: 'Julian Drake (Head of Private Wealth)',
    tprAnalyst: 'Chloe Sanders (Risk Specialist)',
    annualSpendUsd: 620000,
    contractRenewalDate: '2027-06-30',
    contractStartDate: '2024-06-30',
    hostingLocation: 'AWS eu-west-1 (Ireland)',
    dataClassifications: ['NPI / PII', 'Operational Data'],
    applicableFrameworks: ['OCC 2023-29', 'SOC 2 Type II', 'ISO 27001'],
    securityScore: 86,
    scoreGrade: 'B',
    creditStyleScore: 760,
    scoreTrend30d: 0,
    inherentRiskScore: 16,
    residualRiskScore: 6,
    vectorScores: {
      networkSecurity: 88,
      patchCadence: 84,
      applicationSecurity: 89,
      dnsEmailHygiene: 92,
      darkWebExposure: 82,
      endpointHygiene: 86,
      complianceAttestation: 88
    },
    activeFindingsCount: { critical: 0, high: 0, medium: 0, low: 0 },
    questionnaires: [],
    documents: [],
    fourthParties: [
      {
        name: 'Amazon Web Services (AWS)',
        category: 'Cloud Infrastructure',
        provider: 'AWS eu-west-1',
        region: 'Ireland',
        riskLevel: 'High',
        notes: 'Primary CRM database and client communication archives.'
      }
    ],
    recentAlerts: [],
    description: 'Advisory client communication portal, relationship manager CRM, interaction logging, and portfolio recommendation distribution.',
    contactEmail: 'security@kallistocrm.com'
  },
  {
    id: 'ven-007',
    name: 'Prism Treasury Management',
    domain: 'prismtreasury.com',
    tier: 'Tier 1',
    status: 'Active',
    criticality: 'Mission Critical',
    primaryCategory: 'Liquidity, Hedging & FX Execution',
    businessOwner: 'Clara Oswald (Treasurer)',
    tprAnalyst: 'Devon Cross (Senior TPRM Analyst)',
    annualSpendUsd: 2900000,
    contractRenewalDate: '2027-09-15',
    contractStartDate: '2024-09-15',
    hostingLocation: 'Colocation Chicago CME & AWS GovCloud',
    dataClassifications: ['Confidential IP', 'Operational Data'],
    applicableFrameworks: ['OCC 2023-29', 'DORA', 'SOC 2 Type II'],
    securityScore: 94,
    scoreGrade: 'A',
    creditStyleScore: 835,
    scoreTrend30d: 2,
    inherentRiskScore: 22,
    residualRiskScore: 5,
    vectorScores: {
      networkSecurity: 98,
      patchCadence: 95,
      applicationSecurity: 94,
      dnsEmailHygiene: 96,
      darkWebExposure: 90,
      endpointHygiene: 94,
      complianceAttestation: 96
    },
    activeFindingsCount: { critical: 0, high: 0, medium: 0, low: 0 },
    questionnaires: [],
    documents: [],
    fourthParties: [
      {
        name: 'CME Group Colocation',
        category: 'Cloud Infrastructure',
        provider: 'Aurora Illinois Datacenter',
        region: 'United States',
        riskLevel: 'High',
        notes: 'Low-latency financial exchange connection points.'
      }
    ],
    recentAlerts: [],
    description: 'Intraday cash position monitoring, Federal Reserve discount window integration, interest rate swap pricing, and FX currency risk hedging.',
    contactEmail: 'risk@prismtreasury.com'
  },
  {
    id: 'ven-008',
    name: 'Veloce Employee Collaboration',
    domain: 'velocecollab.io',
    tier: 'Tier 3',
    status: 'Active',
    criticality: 'Low',
    primaryCategory: 'Enterprise Chat & Knowledge Base',
    businessOwner: 'Tyler Henderson (Director of IT Operations)',
    tprAnalyst: 'Chloe Sanders (Risk Specialist)',
    annualSpendUsd: 140000,
    contractRenewalDate: '2026-12-15',
    contractStartDate: '2023-12-15',
    hostingLocation: 'AWS us-west-2 (Oregon)',
    dataClassifications: ['Operational Data'],
    applicableFrameworks: ['SOC 2 Type II'],
    securityScore: 89,
    scoreGrade: 'B',
    creditStyleScore: 780,
    scoreTrend30d: 1,
    inherentRiskScore: 8,
    residualRiskScore: 3,
    vectorScores: {
      networkSecurity: 90,
      patchCadence: 92,
      applicationSecurity: 88,
      dnsEmailHygiene: 91,
      darkWebExposure: 82,
      endpointHygiene: 88,
      complianceAttestation: 90
    },
    activeFindingsCount: { critical: 0, high: 0, medium: 0, low: 0 },
    questionnaires: [],
    documents: [],
    fourthParties: [
      {
        name: 'Amazon Web Services (AWS)',
        category: 'Cloud Infrastructure',
        provider: 'AWS us-west-2',
        region: 'United States',
        riskLevel: 'Low',
        notes: 'Standard SaaS hosting for non-confidential employee chat.'
      }
    ],
    recentAlerts: [],
    description: 'Internal project collaboration and team chat. Strictly policy-restricted from handling non-public financial records or customer account credentials.',
    contactEmail: 'trust@velocecollab.io'
  }
];
