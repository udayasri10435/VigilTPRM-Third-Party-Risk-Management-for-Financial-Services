import { QuestionnaireSection, Question } from '../types/tprm';

export const standardSigLiteSections: QuestionnaireSection[] = [
  {
    id: 'sec-ac',
    title: '1. Access Control & Identity Governance',
    domain: 'Access Control',
    weightPercentage: 20,
    questions: [
      {
        id: 'q-ac-01',
        code: 'AC.1',
        domain: 'Access Control',
        question: 'Is multi-factor authentication (MFA) strictly enforced for all administrative and user access to production environments and customer data repositories?',
        guidance: 'Requires FIDO2/WebAuthn or time-based OTP. SMS-based 2FA is deemed insufficient for critical banking workloads under NYDFS 500.12 and OCC guidance.',
        weight: 5,
        response: 'Yes',
        evidenceRequired: true,
        evidenceAttached: 'Okta_MFA_Enforcement_Policy_v4.pdf',
        reviewerScore: 100,
        reviewerNotes: 'Verified MFA policy and enforcement screenshot. Zero exceptions logged.'
      },
      {
        id: 'q-ac-02',
        code: 'AC.2',
        domain: 'Access Control',
        question: 'Are privileged access credentials managed via an enterprise Privileged Access Management (PAM) solution with automated credential rotation and session recording?',
        guidance: 'Must provide automated session termination, credential vaulting, and just-in-time elevation.',
        weight: 4,
        response: 'Yes',
        evidenceRequired: true,
        evidenceAttached: 'CyberArk_PAM_Architecture_Summary.pdf',
        reviewerScore: 95,
        reviewerNotes: 'Rotation cycle set to 24 hours. Session recordings preserved for 365 days.'
      },
      {
        id: 'q-ac-03',
        code: 'AC.3',
        domain: 'Access Control',
        question: 'Are user access privileges formally reviewed on a minimum quarterly basis with management sign-off and documented de-provisioning workflows (revocation within 24h of termination)?',
        guidance: 'Mandated by SOC 2 CC6.2 and OCC Interagency Bulletin for Tier 1 service providers.',
        weight: 4,
        response: 'Partial',
        evidenceRequired: true,
        evidenceAttached: 'Q2_User_Access_Review_Extract.xlsx',
        reviewerScore: 70,
        reviewerNotes: 'Quarterly reviews performed, but de-provisioning audit identified 2 inactive accounts remaining active for 72 hours post-termination.',
        findingRaised: true
      }
    ]
  },
  {
    id: 'sec-crypto',
    title: '2. Cryptography & Key Management',
    domain: 'Data Protection',
    weightPercentage: 15,
    questions: [
      {
        id: 'q-cr-01',
        code: 'CR.1',
        domain: 'Data Protection',
        question: 'Is all customer non-public personal information (NPI) encrypted in transit using TLS 1.3 (or strictly TLS 1.2 with PFS ciphers) and at rest using AES-256 with FIPS 140-3 validated HSMs?',
        guidance: 'Deprecated TLS 1.0/1.1 and insecure cipher suites (RC4, 3DES, CBC mode) are prohibited.',
        weight: 5,
        response: 'Yes',
        evidenceRequired: true,
        evidenceAttached: 'KMS_KeyManagement_Attestation_AWS.pdf',
        reviewerScore: 100,
        reviewerNotes: 'FIPS 140-3 Level 3 HSM keys validated. HSTS with 1-year preload header deployed on all endpoints.'
      },
      {
        id: 'q-cr-02',
        code: 'CR.2',
        domain: 'Data Protection',
        question: 'Does the organization support Bring Your Own Key (BYOK) or Customer Managed Encryption Keys (CMEK) allowing client revocation of cryptographic master keys?',
        guidance: 'Critical for financial institutions retaining cryptographic custody of confidential records.',
        weight: 3,
        response: 'Yes',
        evidenceRequired: false,
        reviewerScore: 90,
        reviewerNotes: 'CMEK supported on enterprise tier via AWS KMS and Azure Key Vault integration.'
      }
    ]
  },
  {
    id: 'sec-bcp',
    title: '3. Business Continuity & Disaster Recovery (BCP/DR)',
    domain: 'Operational Resilience',
    weightPercentage: 25,
    questions: [
      {
        id: 'q-bcp-01',
        code: 'BC.1',
        domain: 'Operational Resilience',
        question: 'Does the vendor maintain a formal Business Continuity & Disaster Recovery Plan that is tested at least annually with documented Recovery Time Objective (RTO <= 4 hours) and Recovery Point Objective (RPO <= 15 minutes)?',
        guidance: 'DORA Article 11 & OCC resilience standards require full failover testing simulating total datacenter/region loss.',
        weight: 5,
        response: 'Yes',
        evidenceRequired: true,
        evidenceAttached: 'Annual_DR_Failover_Simulation_Report_2025.pdf',
        reviewerScore: 95,
        reviewerNotes: 'Actual simulated failover achieved RTO of 1 hour 42 minutes, RPO under 2 minutes.'
      },
      {
        id: 'q-bcp-02',
        code: 'BC.2',
        domain: 'Operational Resilience',
        question: 'Are production databases and critical backups replicated synchronously or asynchronously across geographically distinct availability zones with immutable air-gapped snapshots?',
        guidance: 'Ransomware-resistant backup storage with object-lock immutability for at least 90 days.',
        weight: 4,
        response: 'Yes',
        evidenceRequired: true,
        evidenceAttached: 'S3_ObjectLock_Backup_Architecture.pdf',
        reviewerScore: 100,
        reviewerNotes: 'Multi-region replication across us-east-1 and us-west-2 with S3 Compliance Lock enabled.'
      }
    ]
  },
  {
    id: 'sec-sub',
    title: '4. Subcontracting & 4th-Party Governance',
    domain: 'Concentration & 4th Party',
    weightPercentage: 20,
    questions: [
      {
        id: 'q-sub-01',
        code: 'SP.1',
        domain: 'Concentration & 4th Party',
        question: 'Does the vendor maintain an active inventory of all sub-processors / 4th-party dependencies that handle or process customer data, and contractually require 30 days advance notice before introducing new sub-processors?',
        guidance: 'Mandatory under DORA Article 28(2) and GDPR Article 28.',
        weight: 4,
        response: 'Yes',
        evidenceRequired: true,
        evidenceAttached: 'Master_Subprocessor_List_June2025.pdf',
        reviewerScore: 85,
        reviewerNotes: 'Subprocessor registry published and updated semi-annually. Contractual notification clause verified in MSA §9.3.'
      },
      {
        id: 'q-sub-02',
        code: 'SP.2',
        domain: 'Concentration & 4th Party',
        question: 'Does the vendor conduct formal annual security assessments and SOC 2 / ISO review on its own material subcontractors?',
        guidance: 'Cascade of assurance down the supply chain.',
        weight: 4,
        response: 'Partial',
        evidenceRequired: true,
        evidenceAttached: 'Vendor_Management_Policy_Excerpt.pdf',
        reviewerScore: 65,
        reviewerNotes: 'Assessments conducted for primary cloud infrastructure, but secondary operational tooling sub-processors lack formal annual assessment records.',
        findingRaised: true
      }
    ]
  },
  {
    id: 'sec-vuln',
    title: '5. Vulnerability Management & Incident Response',
    domain: 'Threat & Vulnerability',
    weightPercentage: 20,
    questions: [
      {
        id: 'q-vm-01',
        code: 'VM.1',
        domain: 'Threat & Vulnerability',
        question: 'Is an independent CREST/OSCP-accredited third-party penetration test conducted at least annually on all external and internal API surfaces, with all Critical and High severity findings remediated within 30 days?',
        guidance: 'Executive summary and remediation attestation required for banking audits.',
        weight: 5,
        response: 'Yes',
        evidenceRequired: true,
        evidenceAttached: 'BishopFox_PenTest_ExecSummary_2025.pdf',
        reviewerScore: 90,
        reviewerNotes: 'Pen test completed Oct 2025. 1 High finding resolved in 14 days; re-test passed.'
      },
      {
        id: 'q-vm-02',
        code: 'IR.1',
        domain: 'Threat & Vulnerability',
        question: 'Does the vendor commit to notifying the financial institution within 24 to 72 hours of confirming any security incident or suspected unauthorized disclosure of customer data?',
        guidance: 'NYDFS 23 NYCRR 500 mandates 72-hour regulatory notification; SEC mandates 4 business days.',
        weight: 5,
        response: 'Yes',
        evidenceRequired: true,
        evidenceAttached: 'Incident_Response_Plan_SLA_Extract.pdf',
        reviewerScore: 100,
        reviewerNotes: 'Contractual commitment specifies 24-hour notification for confirmed breaches affecting NPI.'
      }
    ]
  }
];

export const doraIctSections: QuestionnaireSection[] = [
  {
    id: 'dora-resilience',
    title: 'Article 28: ICT Concentration Risk & Multi-Cloud Strategy',
    domain: 'DORA Compliance',
    weightPercentage: 35,
    questions: [
      {
        id: 'dora-01',
        code: 'DORA.28.1',
        domain: 'DORA Compliance',
        question: 'Can the ICT third-party service provider provide complete geographical mapping of where data is processed and stored at rest, including backup facilities within the EU?',
        guidance: 'Digital Operational Resilience Act requirement for European financial entities and foreign subsidiaries.',
        weight: 5,
        response: 'Yes',
        evidenceRequired: true,
        reviewerScore: 95
      },
      {
        id: 'dora-02',
        code: 'DORA.28.2',
        domain: 'DORA Compliance',
        question: 'Does the vendor possess an exit plan ensuring orderly data transition and service continuity to an alternative provider or internal team within 90 days of termination?',
        guidance: 'Exit strategies with tested migration scripts and API data export capabilities.',
        weight: 4,
        response: 'Partial',
        evidenceRequired: true,
        reviewerScore: 60,
        findingRaised: true
      }
    ]
  },
  {
    id: 'dora-testing',
    title: 'Article 26: Advanced Threat-Led Penetration Testing (TLPT)',
    domain: 'DORA Compliance',
    weightPercentage: 35,
    questions: [
      {
        id: 'dora-03',
        code: 'DORA.26.1',
        domain: 'DORA Compliance',
        question: 'Does the vendor participate in Threat-Led Penetration Testing (TLPT / TIBER-EU framework) conducted by financial institution clients or recognized authorities?',
        guidance: 'Testing red-team attack scenarios against live infrastructure.',
        weight: 5,
        response: 'Yes',
        evidenceRequired: true,
        reviewerScore: 90
      }
    ]
  },
  {
    id: 'dora-incident',
    title: 'Article 19: ICT-Related Incident Reporting',
    domain: 'DORA Compliance',
    weightPercentage: 30,
    questions: [
      {
        id: 'dora-04',
        code: 'DORA.19.1',
        domain: 'DORA Compliance',
        question: 'Does the vendor classification scheme distinguish major ICT incidents aligned with the European Supervisory Authorities (EBA/EIOPA/ESMA) criteria?',
        guidance: 'Immediate notification mechanism with initial, intermediate, and final root cause analysis reports.',
        weight: 4,
        response: 'Yes',
        evidenceRequired: true,
        reviewerScore: 100
      }
    ]
  }
];
