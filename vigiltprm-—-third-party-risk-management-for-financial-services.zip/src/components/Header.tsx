import React from 'react';
import { Plus, Download, RefreshCw } from 'lucide-react';

interface HeaderProps {
  currentTab: string;
  onOpenAddVendor: () => void;
  onExportAuditReport: () => void;
  onRunTelemetryScan: () => void;
  isScanning: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  currentTab,
  onOpenAddVendor,
  onExportAuditReport,
  onRunTelemetryScan,
  isScanning
}) => {
  const getBreadcrumbTitle = (tab: string) => {
    switch (tab) {
      case 'dashboard':
        return 'Executive Risk Dashboard';
      case 'vendors':
        return 'Vendor Inventory & Inherent Risk Register';
      case 'questionnaires':
        return 'Security Assessment Engine (SIG / CAIQ / DORA)';
      case 'monitoring':
        return 'Continuous Attack Surface Monitoring & Threat Radar';
      case 'concentration':
        return '4th-Party Concentration Risk & Supply Chain Dependencies';
      case 'remediation':
        return 'Corrective Action Plans (CAP) & SLA Tracker';
      case 'reports':
        return 'Regulatory Assurance & Board Audit Dossier';
      default:
        return 'Vendor Risk Assurance';
    }
  };

  return (
    <header className="h-16 px-6 bg-slate-900/90 backdrop-blur-md border-b border-slate-800 flex items-center justify-between z-10 shrink-0">
      {/* Zone 1 & 2: Contextual Breadcrumb Path */}
      <div className="flex items-center gap-2">
        <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">TPRM Governance</span>
        <span className="text-slate-400" aria-hidden="true">/</span>
        <h2 className="text-sm font-semibold text-slate-100">{getBreadcrumbTitle(currentTab)}</h2>
      </div>

      {/* Zone 3: Primary Action Controls */}
      <div className="flex items-center gap-3">
        <button
          onClick={onRunTelemetryScan}
          disabled={isScanning}
          className="flex items-center gap-2 px-3 py-1.5 text-xs font-medium text-slate-300 bg-slate-800 hover:bg-slate-700 hover:text-white rounded-lg border border-slate-700 transition-colors cursor-pointer disabled:opacity-60"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${isScanning ? 'animate-spin text-cyan-400' : 'text-slate-400'}`} />
          <span>{isScanning ? 'Syncing Telemetry...' : 'Refresh Telemetry'}</span>
        </button>

        <button
          onClick={onExportAuditReport}
          className="flex items-center gap-2 px-3 py-1.5 text-xs font-medium text-slate-300 bg-slate-800 hover:bg-slate-700 hover:text-white rounded-lg border border-slate-700 transition-colors cursor-pointer"
        >
          <Download className="w-3.5 h-3.5 text-slate-400" />
          <span>Export Audit Dossier</span>
        </button>

        <button
          onClick={onOpenAddVendor}
          className="flex items-center gap-2 px-3.5 py-1.5 text-xs font-medium text-white bg-cyan-600 hover:bg-cyan-500 rounded-lg shadow-sm shadow-cyan-900/30 transition-colors cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Onboard New Vendor</span>
        </button>
      </div>
    </header>
  );
};
