import React, { useState, useMemo } from 'react';
import { 
  Search, 
  Filter, 
  ArrowUpDown, 
  Building2, 
  ShieldAlert, 
  ChevronRight, 
  ExternalLink,
  ShieldCheck,
  TrendingDown,
  TrendingUp,
  SlidersHorizontal
} from 'lucide-react';
import { Vendor, RiskTier, VendorStatus, RegulatoryFramework } from '../types/tprm';

interface VendorDirectoryProps {
  vendors: Vendor[];
  onSelectVendor: (vendor: Vendor) => void;
  onOpenAddVendor: () => void;
}

export const VendorDirectory: React.FC<VendorDirectoryProps> = ({
  vendors,
  onSelectVendor,
  onOpenAddVendor,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [tierFilter, setTierFilter] = useState<'All' | RiskTier>('All');
  const [statusFilter, setStatusFilter] = useState<'All' | VendorStatus>('All');
  const [frameworkFilter, setFrameworkFilter] = useState<'All' | RegulatoryFramework>('All');
  const [sortBy, setSortBy] = useState<'risk' | 'score' | 'spend' | 'name'>('risk');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');

  const filteredVendors = useMemo(() => {
    return vendors.filter(vendor => {
      const matchesSearch = 
        vendor.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        vendor.domain.toLowerCase().includes(searchTerm.toLowerCase()) ||
        vendor.primaryCategory.toLowerCase().includes(searchTerm.toLowerCase()) ||
        vendor.businessOwner.toLowerCase().includes(searchTerm.toLowerCase());

      const matchesTier = tierFilter === 'All' || vendor.tier === tierFilter;
      const matchesStatus = statusFilter === 'All' || vendor.status === statusFilter;
      const matchesFramework = frameworkFilter === 'All' || vendor.applicableFrameworks.includes(frameworkFilter);

      return matchesSearch && matchesTier && matchesStatus && matchesFramework;
    }).sort((a, b) => {
      let comparison = 0;
      if (sortBy === 'risk') {
        comparison = a.residualRiskScore - b.residualRiskScore;
      } else if (sortBy === 'score') {
        comparison = a.securityScore - b.securityScore;
      } else if (sortBy === 'spend') {
        comparison = a.annualSpendUsd - b.annualSpendUsd;
      } else if (sortBy === 'name') {
        comparison = a.name.localeCompare(b.name);
      }
      return sortOrder === 'desc' ? -comparison : comparison;
    });
  }, [vendors, searchTerm, tierFilter, statusFilter, frameworkFilter, sortBy, sortOrder]);

  const toggleSort = (field: 'risk' | 'score' | 'spend' | 'name') => {
    if (sortBy === field) {
      setSortOrder(prev => prev === 'asc' ? 'desc' : 'asc');
    } else {
      setSortBy(field);
      setSortOrder('desc');
    }
  };

  return (
    <div className="p-8 space-y-6 max-w-7xl mx-auto">
      {/* Directory Title & Controls */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-white">Vendor Inventory & Inherent Risk Register</h2>
          <p className="text-xs text-slate-400 mt-1">
            Complete inventory of third-party contracts, regulatory classifications, and live security assessments
          </p>
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={onOpenAddVendor}
            className="px-3.5 py-1.5 text-xs font-medium text-white bg-cyan-600 hover:bg-cyan-500 rounded-lg shadow-sm transition-colors cursor-pointer"
          >
            + Onboard New Vendor
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-3">
        <div className="flex flex-col md:flex-row items-center gap-3">
          {/* Search Input */}
          <div className="relative w-full md:flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search vendor name, domain, service category, or owner..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg pl-9 pr-4 py-2 text-xs text-slate-100 placeholder-slate-400 focus:outline-none focus:border-cyan-500"
            />
          </div>

          {/* Tier Filter */}
          <div className="flex items-center gap-1.5 w-full md:w-auto">
            <span className="text-xs text-slate-400 whitespace-nowrap">Tier:</span>
            <div className="flex items-center gap-1 p-1 bg-slate-950 border border-slate-800 rounded-lg text-xs">
              {(['All', 'Tier 1', 'Tier 2', 'Tier 3'] as const).map(t => (
                <button
                  key={t}
                  onClick={() => setTierFilter(t)}
                  className={`px-2.5 py-1 rounded text-xs font-medium transition-colors cursor-pointer ${
                    tierFilter === t ? 'bg-cyan-600 text-white' : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {t}
                </button>
              ))}
            </div>
          </div>

          {/* Status Filter */}
          <div className="flex items-center gap-1.5 w-full md:w-auto">
            <span className="text-xs text-slate-400 whitespace-nowrap">Status:</span>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value as any)}
              className="bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-cyan-500 cursor-pointer"
            >
              <option value="All">All Statuses</option>
              <option value="Active">Active</option>
              <option value="Conditional">Conditional (Remediating)</option>
              <option value="Under Review">Under Review</option>
            </select>
          </div>

          {/* Framework Filter */}
          <div className="flex items-center gap-1.5 w-full md:w-auto">
            <span className="text-xs text-slate-400 whitespace-nowrap">Framework:</span>
            <select
              value={frameworkFilter}
              onChange={(e) => setFrameworkFilter(e.target.value as any)}
              className="bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-cyan-500 cursor-pointer"
            >
              <option value="All">All Regulations</option>
              <option value="OCC 2023-29">OCC 2023-29</option>
              <option value="DORA">EU DORA</option>
              <option value="PCI-DSS v4">PCI-DSS v4</option>
              <option value="NYDFS 500">NYDFS 500</option>
            </select>
          </div>
        </div>

        {/* Filter Summary Stats */}
        <div className="flex items-center justify-between text-xs text-slate-400 pt-2 border-t border-slate-800/60">
          <div>
            Showing <span className="font-mono text-slate-200 font-semibold">{filteredVendors.length}</span> of {vendors.length} vendors in regulatory scope
          </div>
          <div className="flex items-center gap-4">
            <button 
              onClick={() => toggleSort('risk')}
              className={`flex items-center gap-1 hover:text-white cursor-pointer ${sortBy === 'risk' ? 'text-cyan-400 font-medium' : ''}`}
            >
              <span>Residual Risk</span>
              <ArrowUpDown className="w-3 h-3" />
            </button>
            <button 
              onClick={() => toggleSort('score')}
              className={`flex items-center gap-1 hover:text-white cursor-pointer ${sortBy === 'score' ? 'text-cyan-400 font-medium' : ''}`}
            >
              <span>Security Score</span>
              <ArrowUpDown className="w-3 h-3" />
            </button>
            <button 
              onClick={() => toggleSort('spend')}
              className={`flex items-center gap-1 hover:text-white cursor-pointer ${sortBy === 'spend' ? 'text-cyan-400 font-medium' : ''}`}
            >
              <span>Annual Spend</span>
              <ArrowUpDown className="w-3 h-3" />
            </button>
          </div>
        </div>
      </div>

      {/* Main Vendor High-Density Data Grid */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="text-slate-400 border-b border-slate-800 bg-slate-950/40 font-medium">
                <th className="py-3 px-4">Vendor & Criticality</th>
                <th className="py-3 px-3">Service Category</th>
                <th className="py-3 px-3 text-center">Continuous Rating</th>
                <th className="py-3 px-3 text-center">Inherent / Residual</th>
                <th className="py-3 px-3">Data Classification</th>
                <th className="py-3 px-3">Governance Status</th>
                <th className="py-3 px-3 text-right">Annual Contract</th>
                <th className="py-3 px-4 text-right">Dossier</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {filteredVendors.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-12 text-center text-slate-400">
                    No vendors match the specified criteria.
                  </td>
                </tr>
              ) : (
                filteredVendors.map(vendor => (
                  <tr 
                    key={vendor.id} 
                    onClick={() => onSelectVendor(vendor)}
                    className="hover:bg-slate-800/40 transition-colors cursor-pointer group"
                  >
                    {/* Col 1: Vendor Name, Domain & Tier */}
                    <td className="py-3.5 px-4">
                      <div className="flex items-center gap-2.5">
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-semibold text-slate-100 group-hover:text-cyan-300 transition-colors">
                              {vendor.name}
                            </span>
                            <span className={`text-[10px] font-mono px-1.5 py-0.5 rounded font-medium ${
                              vendor.tier === 'Tier 1' ? 'bg-rose-950/70 text-rose-300 border border-rose-800/60' :
                              vendor.tier === 'Tier 2' ? 'bg-amber-950/70 text-amber-300 border border-amber-800/60' :
                              'bg-slate-800 text-slate-300 border border-slate-700'
                            }`}>
                              {vendor.tier}
                            </span>
                          </div>
                          <div className="text-[11px] text-slate-400 font-mono flex items-center gap-1.5 mt-0.5">
                            <span>{vendor.domain}</span>
                            <span aria-hidden="true">·</span>
                            <span>{vendor.criticality}</span>
                          </div>
                        </div>
                      </div>
                    </td>

                    {/* Col 2: Service Category */}
                    <td className="py-3.5 px-3">
                      <div className="text-slate-200 font-medium">{vendor.primaryCategory}</div>
                      <div className="text-[11px] text-slate-400 truncate max-w-[160px]">{vendor.businessOwner}</div>
                    </td>

                    {/* Col 3: Continuous Rating */}
                    <td className="py-3.5 px-3 text-center">
                      <div className="flex items-center justify-center gap-1.5">
                        <span className={`font-mono font-bold text-xs px-2 py-0.5 rounded ${
                          vendor.scoreGrade === 'A' ? 'bg-emerald-950/60 text-emerald-400 border border-emerald-800/60' :
                          vendor.scoreGrade === 'B' ? 'bg-cyan-950/60 text-cyan-400 border border-cyan-800/60' :
                          vendor.scoreGrade === 'C' ? 'bg-amber-950/60 text-amber-400 border border-amber-800/60' :
                          'bg-rose-950/60 text-rose-400 border border-rose-800/60'
                        }`}>
                          {vendor.scoreGrade}
                        </span>
                        <div className="text-left font-mono tabular-nums text-xs">
                          <span className="text-slate-100 font-medium">{vendor.securityScore}</span>
                          <span className="text-[10px] text-slate-400">/100</span>
                        </div>
                        {vendor.scoreTrend30d < 0 ? (
                          <TrendingDown className="w-3.5 h-3.5 text-rose-400" />
                        ) : (
                          <TrendingUp className="w-3.5 h-3.5 text-emerald-400" />
                        )}
                      </div>
                    </td>

                    {/* Col 4: Inherent vs Residual */}
                    <td className="py-3.5 px-3 text-center font-mono tabular-nums">
                      <div className="flex items-center justify-center gap-1.5 text-xs">
                        <span className="text-amber-400" title="Inherent Risk">{vendor.inherentRiskScore}</span>
                        <span className="text-slate-400">→</span>
                        <span className={`font-bold ${
                          vendor.residualRiskScore > 12 ? 'text-rose-400' :
                          vendor.residualRiskScore > 8 ? 'text-amber-400' : 'text-emerald-400'
                        }`} title="Residual Risk">
                          {vendor.residualRiskScore}
                        </span>
                        <span className="text-[10px] text-slate-400">/25</span>
                      </div>
                    </td>

                    {/* Col 5: Data Classification */}
                    <td className="py-3.5 px-3">
                      <div className="flex flex-wrap gap-1 max-w-[170px]">
                        {vendor.dataClassifications.map(dc => (
                          <span key={dc} className="text-[10px] px-1.5 py-0.5 rounded bg-slate-950 border border-slate-800 text-slate-300">
                            {dc}
                          </span>
                        ))}
                      </div>
                    </td>

                    {/* Col 6: Governance Status */}
                    <td className="py-3.5 px-3">
                      <div className="space-y-0.5">
                        <span className={`inline-block text-[11px] font-medium ${
                          vendor.status === 'Active' ? 'text-emerald-400' :
                          vendor.status === 'Conditional' ? 'text-amber-400' : 'text-cyan-400'
                        }`}>
                          {vendor.status}
                        </span>
                        <div className="text-[10px] text-slate-400 font-mono">
                          Renewal: {vendor.contractRenewalDate}
                        </div>
                      </div>
                    </td>

                    {/* Col 7: Annual Contract Spend */}
                    <td className="py-3.5 px-3 text-right font-mono tabular-nums text-slate-200">
                      ${(vendor.annualSpendUsd / 1000).toLocaleString()}k
                    </td>

                    {/* Col 8: Action / Chevron */}
                    <td className="py-3.5 px-4 text-right">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onSelectVendor(vendor);
                        }}
                        className="px-2.5 py-1 text-xs font-medium text-cyan-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded border border-slate-700 transition-colors inline-flex items-center gap-1 cursor-pointer"
                      >
                        <span>Inspect</span>
                        <ChevronRight className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
