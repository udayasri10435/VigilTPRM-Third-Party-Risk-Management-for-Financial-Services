import React, { useState, useMemo } from 'react';
import { 
  ArrowLeft, 
  CheckCircle2, 
  AlertTriangle, 
  FileText, 
  Upload, 
  Paperclip, 
  Flag, 
  HelpCircle,
  Save,
  Check,
  Percent,
  Search,
  SlidersHorizontal
} from 'lucide-react';
import { VendorQuestionnaire, Question, QuestionnaireSection } from '../types/tprm';

interface QuestionnaireViewerProps {
  questionnaire: VendorQuestionnaire;
  onBack: () => void;
  onSaveQuestionnaire: (updated: VendorQuestionnaire) => void;
  onRaiseFindingFromQuestion: (q: Question, vendorName: string, vendorId: string) => void;
}

export const QuestionnaireViewer: React.FC<QuestionnaireViewerProps> = ({
  questionnaire,
  onBack,
  onSaveQuestionnaire,
  onRaiseFindingFromQuestion
}) => {
  const [activeSectionId, setActiveSectionId] = useState<string>(questionnaire.sections[0]?.id || '');
  const [filterMode, setFilterMode] = useState<'all' | 'flagged' | 'partial_no' | 'unanswered'>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [sections, setSections] = useState<QuestionnaireSection[]>(questionnaire.sections);
  const [hasSaved, setHasSaved] = useState(false);

  const currentSection = useMemo(() => {
    return sections.find(s => s.id === activeSectionId) || sections[0];
  }, [sections, activeSectionId]);

  // Recalculate dynamic overall score
  const overallScoreCalculated = useMemo(() => {
    let totalWeightedScore = 0;
    let totalWeight = 0;

    sections.forEach(section => {
      let sectionQuestionsScore = 0;
      let sectionQuestionsWeight = 0;

      section.questions.forEach(q => {
        if (q.response !== 'Not Applicable') {
          const score = q.reviewerScore !== undefined ? q.reviewerScore : (
            q.response === 'Yes' ? 100 :
            q.response === 'Partial' ? 50 : 0
          );
          sectionQuestionsScore += score * q.weight;
          sectionQuestionsWeight += q.weight;
        }
      });

      if (sectionQuestionsWeight > 0) {
        const sectionAvg = sectionQuestionsScore / sectionQuestionsWeight;
        totalWeightedScore += sectionAvg * (section.weightPercentage / 100);
        totalWeight += (section.weightPercentage / 100);
      }
    });

    return Math.round(totalWeight > 0 ? (totalWeightedScore / totalWeight) : 0);
  }, [sections]);

  const totalQuestions = useMemo(() => {
    return sections.reduce((acc, s) => acc + s.questions.length, 0);
  }, [sections]);

  const answeredQuestions = useMemo(() => {
    return sections.reduce((acc, s) => acc + s.questions.filter(q => q.response).length, 0);
  }, [sections]);

  const completionPercentage = Math.round((answeredQuestions / (totalQuestions || 1)) * 100);

  const totalFlaggedDeficiencies = useMemo(() => {
    return sections.reduce((acc, s) => acc + s.questions.filter(q => q.findingRaised).length, 0);
  }, [sections]);

  // Handle updates to individual questions
  const updateQuestion = (questionId: string, updates: Partial<Question>) => {
    setSections(prevSections => {
      return prevSections.map(sec => {
        if (sec.id !== activeSectionId) return sec;
        return {
          ...sec,
          questions: sec.questions.map(q => {
            if (q.id !== questionId) return q;
            const updatedQuestion = { ...q, ...updates };

            // If response changed, set default reviewer score
            if (updates.response && updates.reviewerScore === undefined) {
              if (updates.response === 'Yes') updatedQuestion.reviewerScore = 100;
              else if (updates.response === 'Partial') updatedQuestion.reviewerScore = 60;
              else if (updates.response === 'No') updatedQuestion.reviewerScore = 0;
            }

            return updatedQuestion;
          })
        };
      });
    });
    setHasSaved(false);
  };

  const handleSave = () => {
    const updatedQuestionnaire: VendorQuestionnaire = {
      ...questionnaire,
      sections,
      overallScore: overallScoreCalculated,
      completionRate: completionPercentage,
      lastUpdated: new Date().toISOString().split('T')[0]
    };
    onSaveQuestionnaire(updatedQuestionnaire);
    setHasSaved(true);
    setTimeout(() => setHasSaved(false), 2500);
  };

  // Filter questions for the active section
  const visibleQuestions = useMemo(() => {
    if (!currentSection) return [];
    return currentSection.questions.filter(q => {
      const matchesSearch = 
        q.question.toLowerCase().includes(searchTerm.toLowerCase()) ||
        q.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
        q.guidance.toLowerCase().includes(searchTerm.toLowerCase());

      if (!matchesSearch) return false;

      if (filterMode === 'flagged') return q.findingRaised;
      if (filterMode === 'partial_no') return q.response === 'Partial' || q.response === 'No';
      if (filterMode === 'unanswered') return !q.response;
      return true;
    });
  }, [currentSection, filterMode, searchTerm]);

  return (
    <div className="p-8 space-y-6 max-w-7xl mx-auto">
      {/* Top Banner Navigation */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            className="p-2 rounded-lg bg-slate-900 border border-slate-800 text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-mono text-cyan-400 font-semibold">{questionnaire.standard}</span>
              <span className="text-slate-400" aria-hidden="true">·</span>
              <span className="text-xs text-slate-400">{questionnaire.vendorName}</span>
            </div>
            <h2 className="text-lg font-bold text-white tracking-tight">{questionnaire.title}</h2>
          </div>
        </div>

        {/* Dynamic Score & Actions */}
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-3 bg-slate-900 border border-slate-800 px-4 py-2 rounded-xl text-xs font-mono">
            <div>
              <span className="text-slate-400 block text-[10px]">Assurance Score</span>
              <span className="text-base font-bold text-cyan-400 tabular-nums">{overallScoreCalculated} / 100</span>
            </div>
            <div className="w-px h-8 bg-slate-800" />
            <div>
              <span className="text-slate-400 block text-[10px]">Completion</span>
              <span className="text-base font-bold text-slate-200 tabular-nums">{completionPercentage}%</span>
            </div>
            <div className="w-px h-8 bg-slate-800" />
            <div>
              <span className="text-slate-400 block text-[10px]">Findings Flagged</span>
              <span className="text-base font-bold text-rose-400 tabular-nums">{totalFlaggedDeficiencies}</span>
            </div>
          </div>

          <button
            onClick={handleSave}
            className={`px-4 py-2.5 rounded-lg text-xs font-medium transition-all flex items-center gap-1.5 cursor-pointer shadow-sm ${
              hasSaved 
                ? 'bg-emerald-600 text-white' 
                : 'bg-cyan-600 hover:bg-cyan-500 text-white'
            }`}
          >
            {hasSaved ? (
              <>
                <Check className="w-3.5 h-3.5" />
                <span>Changes Saved</span>
              </>
            ) : (
              <>
                <Save className="w-3.5 h-3.5" />
                <span>Save Assessment</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Main Grid: Section Nav (Left) + Questions (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Left Column: Sections List */}
        <div className="lg:col-span-1 space-y-2">
          <span className="text-xs font-semibold uppercase tracking-wider text-slate-400 px-2 block">
            Assessment Domains
          </span>
          <div className="space-y-1">
            {sections.map((section, idx) => {
              const isActive = section.id === activeSectionId;
              const answeredInSection = section.questions.filter(q => q.response).length;
              const hasDeficiencies = section.questions.some(q => q.findingRaised);

              return (
                <button
                  key={section.id}
                  onClick={() => setActiveSectionId(section.id)}
                  className={`w-full text-left p-3 rounded-xl border text-xs transition-all cursor-pointer ${
                    isActive
                      ? 'bg-slate-900 border-cyan-700/60 shadow-sm text-white'
                      : 'bg-slate-950/40 border-slate-800/80 text-slate-300 hover:bg-slate-900/60'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-semibold text-slate-200 truncate pr-2">{section.title}</span>
                    {hasDeficiencies && (
                      <Flag className="w-3.5 h-3.5 text-rose-400 shrink-0" />
                    )}
                  </div>
                  <div className="flex items-center justify-between text-[11px] text-slate-400 font-mono">
                    <span>Weight: {section.weightPercentage}%</span>
                    <span>{answeredInSection}/{section.questions.length} answered</span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Right Column: Questions List & Controls */}
        <div className="lg:col-span-3 space-y-4">
          {/* Controls Bar */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-3 flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs">
            <div className="relative flex-1">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search question, code, or guidance..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg pl-8 pr-3 py-1.5 text-xs text-slate-200 placeholder-slate-400 focus:outline-none focus:border-cyan-500"
              />
            </div>

            <div className="flex items-center gap-1 bg-slate-950 p-1 border border-slate-800 rounded-lg">
              <button
                onClick={() => setFilterMode('all')}
                className={`px-2.5 py-1 rounded text-[11px] font-medium transition-colors cursor-pointer ${
                  filterMode === 'all' ? 'bg-cyan-600 text-white' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                All ({currentSection?.questions.length})
              </button>
              <button
                onClick={() => setFilterMode('flagged')}
                className={`px-2.5 py-1 rounded text-[11px] font-medium transition-colors cursor-pointer ${
                  filterMode === 'flagged' ? 'bg-rose-600 text-white' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Deficiencies ({currentSection?.questions.filter(q => q.findingRaised).length})
              </button>
              <button
                onClick={() => setFilterMode('partial_no')}
                className={`px-2.5 py-1 rounded text-[11px] font-medium transition-colors cursor-pointer ${
                  filterMode === 'partial_no' ? 'bg-amber-600 text-white' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Partial / No ({currentSection?.questions.filter(q => q.response === 'Partial' || q.response === 'No').length})
              </button>
            </div>
          </div>

          {/* Questions Container */}
          <div className="space-y-4">
            {visibleQuestions.length === 0 ? (
              <div className="py-12 text-center text-slate-400 bg-slate-900 border border-slate-800 rounded-xl">
                No questions match the current filter in this section.
              </div>
            ) : (
              visibleQuestions.map((q) => (
                <div 
                  key={q.id}
                  className={`p-5 rounded-xl border transition-colors space-y-4 ${
                    q.findingRaised 
                      ? 'bg-slate-900/90 border-rose-900/60 shadow-sm shadow-rose-950/20' 
                      : 'bg-slate-900 border-slate-800'
                  }`}
                >
                  {/* Question Header */}
                  <div className="flex items-start justify-between gap-4">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-bold text-xs text-cyan-400 bg-cyan-950/60 px-2 py-0.5 rounded border border-cyan-800/60">
                          {q.code}
                        </span>
                        <span className="text-xs text-slate-400 font-mono">Domain: {q.domain}</span>
                        <span className="text-slate-400" aria-hidden="true">·</span>
                        <span className="text-xs text-slate-400 font-mono">Weight: {q.weight}/5</span>
                      </div>
                      <h4 className="text-sm font-semibold text-slate-100 leading-snug">{q.question}</h4>
                    </div>

                    <button
                      onClick={() => {
                        const newFlag = !q.findingRaised;
                        updateQuestion(q.id, { findingRaised: newFlag });
                        if (newFlag) {
                          onRaiseFindingFromQuestion(q, questionnaire.vendorName, questionnaire.vendorId);
                        }
                      }}
                      className={`px-2.5 py-1 text-xs rounded-lg border flex items-center gap-1.5 transition-colors cursor-pointer shrink-0 ${
                        q.findingRaised
                          ? 'bg-rose-950 text-rose-300 border-rose-800 font-medium'
                          : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-slate-200'
                      }`}
                      title="Flag deficiency and log finding to CAP"
                    >
                      <Flag className="w-3.5 h-3.5" />
                      <span>{q.findingRaised ? 'Deficiency Raised' : 'Flag Issue'}</span>
                    </button>
                  </div>

                  {/* Guidance */}
                  <div className="p-3 bg-slate-950/70 border border-slate-800/80 rounded-lg text-xs text-slate-400 flex items-start gap-2">
                    <HelpCircle className="w-4 h-4 text-slate-400 shrink-0 mt-0.5" />
                    <div>
                      <span className="text-slate-300 font-medium">Regulatory Audit Guidance: </span>
                      {q.guidance}
                    </div>
                  </div>

                  {/* Response Segmented Buttons */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-1">
                    <div>
                      <span className="text-xs font-medium text-slate-300 block mb-2">Vendor Stated Response</span>
                      <div className="grid grid-cols-4 gap-1.5 bg-slate-950 p-1 rounded-lg border border-slate-800 text-xs">
                        {(['Yes', 'Partial', 'No', 'Not Applicable'] as const).map((resp) => {
                          const isSelected = q.response === resp;
                          return (
                            <button
                              key={resp}
                              onClick={() => updateQuestion(q.id, { response: resp })}
                              className={`py-1.5 px-2 rounded font-medium text-center transition-colors cursor-pointer text-xs ${
                                isSelected
                                  ? resp === 'Yes' ? 'bg-emerald-600 text-white' :
                                    resp === 'Partial' ? 'bg-amber-600 text-white' :
                                    resp === 'No' ? 'bg-rose-600 text-white' : 'bg-slate-700 text-white'
                                  : 'text-slate-400 hover:text-slate-200'
                              }`}
                            >
                              {resp}
                            </button>
                          );
                        })}
                      </div>
                    </div>

                    {/* Reviewer Score & Verification */}
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-xs font-medium text-slate-300">Auditor Verified Score</span>
                        <span className="text-xs font-mono font-bold text-cyan-400 tabular-nums">
                          {q.reviewerScore ?? 100} / 100
                        </span>
                      </div>
                      <input
                        type="range"
                        min="0"
                        max="100"
                        step="5"
                        value={q.reviewerScore ?? 100}
                        onChange={(e) => updateQuestion(q.id, { reviewerScore: parseInt(e.target.value) })}
                        className="w-full accent-cyan-500 cursor-pointer h-2 bg-slate-950 rounded-lg"
                      />
                    </div>
                  </div>

                  {/* Evidence Attachment & Reviewer Notes */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-2 border-t border-slate-800/60 text-xs">
                    <div>
                      <span className="text-slate-400 block mb-1">Attached Audit Evidence</span>
                      {q.evidenceAttached ? (
                        <div className="flex items-center justify-between p-2 rounded bg-slate-950 border border-slate-800 font-mono text-[11px] text-cyan-300">
                          <div className="flex items-center gap-1.5 truncate">
                            <Paperclip className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                            <span className="truncate">{q.evidenceAttached}</span>
                          </div>
                          <span className="text-[10px] text-emerald-400 shrink-0 ml-2">Verified</span>
                        </div>
                      ) : (
                        <button
                          onClick={() => updateQuestion(q.id, { evidenceAttached: `${q.code}_Evidence_Documentation.pdf` })}
                          className="w-full p-2 border border-dashed border-slate-800 rounded bg-slate-950/40 text-slate-400 hover:text-slate-200 flex items-center justify-center gap-1.5 cursor-pointer text-xs"
                        >
                          <Upload className="w-3.5 h-3.5" />
                          <span>Attach Compliance Verification Artifact</span>
                        </button>
                      )}
                    </div>

                    <div>
                      <span className="text-slate-400 block mb-1">Auditor Evaluation Notes</span>
                      <input
                        type="text"
                        placeholder="Add review notes, compensating controls or audit citations..."
                        value={q.reviewerNotes || ''}
                        onChange={(e) => updateQuestion(q.id, { reviewerNotes: e.target.value })}
                        className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-xs text-slate-200 placeholder-slate-400 focus:outline-none focus:border-cyan-500"
                      />
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
