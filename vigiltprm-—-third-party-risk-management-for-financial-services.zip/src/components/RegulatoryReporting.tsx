import React, { useState } from 'react';
import { 
  FileText, 
  Download, 
  Printer, 
  CheckCircle2, 
  Shield, 
  Building, 
  Calendar, 
  Layers, 
  AlertTriangle,
  Award
} from 'lucide-react';
import { Vendor, InstitutionProfile, Finding } from '../types/tprm';

interface RegulatoryReportingProps {
  vendors: Vendor[];
  findings: Finding[];
  institution: InstitutionProfile;
}

export const RegulatoryReporting: React.FC<RegulatoryReportingProps> = ({
  vendors,
  findings,
  institution
}) => {
  const [reportType, setReportType] = useState<'board' | 'occ' | 'dora'>('board');
  const [isExporting, setIsExporting] = useState(false);

  const tier1Vendors = vendors.filter(v => v.tier === 'Tier 1');
  const totalSpend = vendors.reduce((acc, v) => acc + v.annualSpendUsd, 0);
  const openCriticalFindings = findings.filter(f => f.severity === 'Critical' && f.status !== 'Resolved');

  const handleDownloadCsv = () => {
    setIsExporting(true);
    const headers = ['Vendor Name', 'Domain', 'Tier', 'Criticality', 'Security Score', 'Inherent Risk', 'Residual Risk', 'Annual Spend USD', 'Status', 'Renewal Date'];
    const rows = vendors.map(v => [
      `"${v.name}"`,
      `"${v.domain}"`,
      `"${v.tier}"`,
      `"${v.criticality}"`,
      v.securityScore,
      v.inherentRiskScore,
      v.residualRiskScore,
      v.annualSpendUsd,
      `"${v.status}"`,
      `"${v.contractRenewalDate}"`
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `VigilTPRM_Regulatory_Inventory_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    setTimeout(() => setIsExporting(false), 800);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="p-8 space-y-6 max-w-7xl mx-auto">
      {/* Top Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-white flex items-center gap-2">
            <FileText className="w-5 h-5 text-cyan-400" />
            <span>Regulatory Assurance & Board Audit Dossier</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Automated compliance reporting aligned with OCC Bulletin 2013-29, 2023 Interagency Guidance, and EU DORA
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={handleDownloadCsv}
            disabled={isExporting}
            className="flex items-center gap-2 px-3.5 py-1.5 text-xs font-medium text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-lg border border-slate-700 transition-colors cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            <span>{isExporting ? 'Generating CSV...' : 'Download CSV Register'}</span>
          </button>

          <button
            onClick={handlePrint}
            className="flex items-center gap-2 px-3.5 py-1.5 text-xs font-medium text-white bg-cyan-600 hover:bg-cyan-500 rounded-lg shadow-sm transition-colors cursor-pointer"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print Dossier / PDF</span>
          </button>
        </div>
      </div>

      {/* Report Template Selector */}
      <div className="flex items-center gap-2 p-1 bg-slate-900 border border-slate-800 rounded-xl text-xs">
        <button
          onClick={() => setReportType('board')}
          className={`flex-1 py-2 rounded-lg font-medium transition-colors cursor-pointer ${
            reportType === 'board' ? 'bg-cyan-600 text-white' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          Board of Directors Executive Summary
        </button>
        <button
          onClick={() => setReportType('occ')}
          className={`flex-1 py-2 rounded-lg font-medium transition-colors cursor-pointer ${
            reportType === 'occ' ? 'bg-cyan-600 text-white' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          OCC 2023-29 Interagency Guidance Audit
        </button>
        <button
          onClick={() => setReportType('dora')}
          className={`flex-1 py-2 rounded-lg font-medium transition-colors cursor-pointer ${
            reportType === 'dora' ? 'bg-cyan-600 text-white' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          EU DORA (Article 28) Register of Information
        </button>
      </div>

      {/* Report Paper Preview Container */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-8 space-y-8 shadow-xl print:bg-white print:text-black print:border-none print:shadow-none">
        {/* Document Header */}
        <div className="flex flex-col md:flex-row md:items-start justify-between gap-4 pb-6 border-b border-slate-800 print:border-black">
          <div>
            <div className="flex items-center gap-2 text-xs font-mono text-cyan-400 print:text-black">
              <Shield className="w-4 h-4" />
              <span>OFFICE OF THE CHIEF INFORMATION SECURITY OFFICER & TPRM COMMITTEE</span>
            </div>
            <h1 className="text-2xl font-bold text-white print:text-black mt-2">
              {reportType === 'board' && 'Quarterly Third-Party Risk & Critical Vendor Oversight Report'}
              {reportType === 'occ' && 'OCC Bulletin 2013-29 / 2023 Interagency Guidance Examination Packet'}
              {reportType === 'dora' && 'EU DORA ICT Third-Party Service Provider Information Register'}
            </h1>
            <p className="text-xs text-slate-400 print:text-black mt-1">
              Institution: <strong>{institution.name}</strong> · Supervisory Authority: OCC, FRB, FDIC · Confidential Supervisory Material
            </p>
          </div>

          <div className="text-right text-xs font-mono text-slate-400 print:text-black space-y-1">
            <div>Report Date: <strong>{new Date().toISOString().split('T')[0]}</strong></div>
            <div>Attestation Cycle: <strong>Q3 2026</strong></div>
            <div className="text-emerald-400 print:text-black font-semibold">Classification: RESTRICTED</div>
          </div>
        </div>

        {/* Executive Summary Metrics */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="p-4 bg-slate-950/60 print:bg-slate-100 rounded-xl border border-slate-800 print:border-black">
            <span className="text-[11px] text-slate-400 print:text-black block">Supervised Third Parties</span>
            <div className="text-2xl font-bold text-white print:text-black font-mono mt-1">{vendors.length} Total</div>
            <span className="text-[11px] text-cyan-400 print:text-black mt-1 block">{tier1Vendors.length} Mission-Critical Tier 1</span>
          </div>

          <div className="p-4 bg-slate-950/60 print:bg-slate-100 rounded-xl border border-slate-800 print:border-black">
            <span className="text-[11px] text-slate-400 print:text-black block">Aggregate Annual Spend</span>
            <div className="text-2xl font-bold text-white print:text-black font-mono mt-1">${(totalSpend / 1000000).toFixed(1)}M USD</div>
            <span className="text-[11px] text-slate-400 print:text-black mt-1 block">Contracted Commitments</span>
          </div>

          <div className="p-4 bg-slate-950/60 print:bg-slate-100 rounded-xl border border-slate-800 print:border-black">
            <span className="text-[11px] text-slate-400 print:text-black block">Residual Risk Index</span>
            <div className="text-2xl font-bold text-emerald-400 print:text-black font-mono mt-1">{institution.averageResidualRisk} / 25</div>
            <span className="text-[11px] text-emerald-400 print:text-black mt-1 block">Within Risk Appetite</span>
          </div>

          <div className="p-4 bg-slate-950/60 print:bg-slate-100 rounded-xl border border-slate-800 print:border-black">
            <span className="text-[11px] text-slate-400 print:text-black block">Open Critical SLA Items</span>
            <div className="text-2xl font-bold text-rose-400 print:text-black font-mono mt-1">{openCriticalFindings.length} Items</div>
            <span className="text-[11px] text-rose-400 print:text-black mt-1 block">Action Plans Active</span>
          </div>
        </div>

        {/* Section 1: OCC Lifecycle Governance Attestation */}
        <div className="space-y-4">
          <h3 className="text-sm font-bold text-white print:text-black uppercase tracking-wider border-b border-slate-800 print:border-black pb-2">
            1. Third-Party Risk Management Lifecycle Governance (2023 Interagency Stages)
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-5 gap-3 text-xs">
            {[
              { stage: '1. Planning', status: 'Compliant', desc: 'Inherent risk assessment completed prior to contract execution.' },
              { stage: '2. Due Diligence', status: 'Compliant', desc: 'Independent SIG, SOC 2, and audited financial verification.' },
              { stage: '3. Contract Negotiation', status: 'Compliant', desc: 'Mandatory audit rights, DORA exit plans, and 72h breach notification clauses.' },
              { stage: '4. Ongoing Monitoring', status: 'Active 24/7', desc: 'Daily attack surface recon, CVE tracking, and quarterly access reviews.' },
              { stage: '5. Termination & Exit', status: 'Documented', desc: 'Transition plans and tested escrow data export scripts for Tier 1 providers.' },
            ].map(item => (
              <div key={item.stage} className="p-3 bg-slate-950/40 print:bg-white rounded-lg border border-slate-800 print:border-black space-y-1">
                <span className="font-semibold text-slate-200 print:text-black">{item.stage}</span>
                <div className="text-emerald-400 print:text-black font-medium text-[11px]">{item.status}</div>
                <p className="text-[11px] text-slate-400 print:text-black">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Section 2: Critical Tier 1 Vendor Assurance Summary */}
        <div className="space-y-3">
          <h3 className="text-sm font-bold text-white print:text-black uppercase tracking-wider border-b border-slate-800 print:border-black pb-2">
            2. Tier 1 Critical Vendor Assurance Table
          </h3>
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="text-slate-400 print:text-black border-b border-slate-800 print:border-black font-medium">
                <th className="pb-2">Vendor Name</th>
                <th className="pb-2">Function</th>
                <th className="pb-2 text-center">Inherent Risk</th>
                <th className="pb-2 text-center">Residual Risk</th>
                <th className="pb-2 text-center">Security Rating</th>
                <th className="pb-2">SOC 2 Period End</th>
                <th className="pb-2">Supervisory Clearance</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 print:divide-black">
              {tier1Vendors.map(v => (
                <tr key={v.id} className="py-2">
                  <td className="py-2.5 font-semibold text-slate-100 print:text-black">{v.name}</td>
                  <td className="py-2.5 text-slate-300 print:text-black">{v.primaryCategory}</td>
                  <td className="py-2.5 text-center font-mono text-amber-400 print:text-black">{v.inherentRiskScore} / 25</td>
                  <td className="py-2.5 text-center font-mono font-bold text-emerald-400 print:text-black">{v.residualRiskScore} / 25</td>
                  <td className="py-2.5 text-center font-mono text-slate-200 print:text-black">{v.securityScore} (Grade {v.scoreGrade})</td>
                  <td className="py-2.5 font-mono text-slate-400 print:text-black text-[11px]">
                    {v.documents[0]?.periodEnd || 'Current'}
                  </td>
                  <td className="py-2.5">
                    <span className="text-emerald-400 print:text-black font-medium text-[11px] flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      Approved
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Section 3: Attestation Sign-off Block */}
        <div className="pt-6 border-t border-slate-800 print:border-black grid grid-cols-1 md:grid-cols-2 gap-8 text-xs">
          <div className="space-y-4">
            <span className="font-semibold text-slate-300 print:text-black block">Prepared by Third-Party Risk Officer:</span>
            <div className="h-12 border-b border-slate-700 print:border-black flex items-end pb-1 font-mono text-cyan-300 print:text-black">
              Elena Rostova, CISM (VP, Third-Party Risk)
            </div>
            <div className="text-[11px] text-slate-400 print:text-black">Date: {new Date().toLocaleDateString()}</div>
          </div>

          <div className="space-y-4">
            <span className="font-semibold text-slate-300 print:text-black block">Executive Sign-Off & Committee Approval:</span>
            <div className="h-12 border-b border-slate-700 print:border-black flex items-end pb-1 font-mono text-cyan-300 print:text-black">
              Liam Sterling (Chief Information Security Officer)
            </div>
            <div className="text-[11px] text-slate-400 print:text-black">Cleared for Board Risk Committee Presentation</div>
          </div>
        </div>
      </div>
    </div>
  );
};
