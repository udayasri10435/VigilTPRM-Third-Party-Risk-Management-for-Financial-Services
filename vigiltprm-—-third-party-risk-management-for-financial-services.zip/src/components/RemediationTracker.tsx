import React, { useState } from 'react';
import { 
  AlertOctagon, 
  CheckCircle2, 
  Clock, 
  Search, 
  Filter, 
  Check, 
  X, 
  ShieldCheck, 
  Send, 
  FileCheck2,
  ExternalLink
} from 'lucide-react';
import { Finding } from '../types/tprm';

interface RemediationTrackerProps {
  findings: Finding[];
  onResolveFinding: (findingId: string) => void;
  onAcceptRisk: (findingId: string, justification: string) => void;
}

export const RemediationTracker: React.FC<RemediationTrackerProps> = ({
  findings,
  onResolveFinding,
  onAcceptRisk,
}) => {
  const [statusFilter, setStatusFilter] = useState<'All' | 'Open' | 'In Remediation' | 'Resolved'>('All');
  const [severityFilter, setSeverityFilter] = useState<string>('All');
  const [searchTerm, setSearchTerm] = useState('');
  const [riskAcceptModalFinding, setRiskAcceptModalFinding] = useState<Finding | null>(null);
  const [justificationText, setJustificationText] = useState('');
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const filteredFindings = findings.filter(f => {
    const matchesSearch = 
      f.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      f.vendorName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      f.description.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesStatus = statusFilter === 'All' || f.status === statusFilter;
    const matchesSeverity = severityFilter === 'All' || f.severity === severityFilter;

    return matchesSearch && matchesStatus && matchesSeverity;
  });

  const handleSendReminder = (vendorName: string) => {
    setToastMessage(`Automated SLA reminder email sent to ${vendorName} security lead.`);
    setTimeout(() => setToastMessage(null), 3000);
  };

  return (
    <div className="p-8 space-y-6 max-w-7xl mx-auto">
      {/* Toast */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-slate-900 border border-cyan-500 text-cyan-200 px-4 py-3 rounded-xl shadow-xl flex items-center gap-2 text-xs">
          <CheckCircle2 className="w-4 h-4 text-cyan-400" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-white flex items-center gap-2">
            <AlertOctagon className="w-5 h-5 text-rose-400" />
            <span>Corrective Action Plans (CAP) & SLA Remediation Tracker</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Tracking vendor security deficiencies, remediation commitments, and contractual SLAs under OCC & NYDFS mandates
          </p>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-3">
        <div className="flex flex-col md:flex-row items-center gap-3">
          <div className="relative w-full md:flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search finding by title, vendor, or description..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg pl-9 pr-4 py-2 text-xs text-slate-100 placeholder-slate-400 focus:outline-none focus:border-cyan-500"
            />
          </div>

          <div className="flex items-center gap-1.5 w-full md:w-auto">
            <span className="text-xs text-slate-400">Status:</span>
            <div className="flex items-center gap-1 p-1 bg-slate-950 border border-slate-800 rounded-lg text-xs">
              {(['All', 'Open', 'In Remediation', 'Resolved'] as const).map(st => (
                <button
                  key={st}
                  onClick={() => setStatusFilter(st)}
                  className={`px-2.5 py-1 rounded text-xs font-medium transition-colors cursor-pointer ${
                    statusFilter === st ? 'bg-cyan-600 text-white' : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {st}
                </button>
              ))}
            </div>
          </div>

          <div className="flex items-center gap-1.5 w-full md:w-auto">
            <span className="text-xs text-slate-400">Severity:</span>
            <select
              value={severityFilter}
              onChange={(e) => setSeverityFilter(e.target.value)}
              className="bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-cyan-500 cursor-pointer"
            >
              <option value="All">All Severities</option>
              <option value="Critical">Critical (30-day SLA)</option>
              <option value="High">High (60-day SLA)</option>
              <option value="Medium">Medium (90-day SLA)</option>
            </select>
          </div>
        </div>
      </div>

      {/* Findings List */}
      <div className="space-y-4">
        {filteredFindings.length === 0 ? (
          <div className="py-16 text-center text-slate-400 bg-slate-900 border border-slate-800 rounded-xl space-y-2">
            <CheckCircle2 className="w-8 h-8 text-emerald-400 mx-auto" />
            <p className="text-xs font-medium text-slate-200">No deficiencies matching current filters</p>
            <p className="text-[11px] text-slate-400">All vendor action plans have been remediated or verified.</p>
          </div>
        ) : (
          filteredFindings.map(finding => {
            const isResolved = finding.status === 'Resolved';
            const isCritical = finding.severity === 'Critical';

            return (
              <div 
                key={finding.id}
                className={`p-5 rounded-xl border transition-all space-y-4 ${
                  isResolved
                    ? 'bg-slate-900/40 border-slate-800/60 opacity-70'
                    : isCritical
                    ? 'bg-slate-900/90 border-rose-900/70 shadow-sm shadow-rose-950/20'
                    : 'bg-slate-900 border-slate-800'
                }`}
              >
                <div className="flex flex-col md:flex-row md:items-start justify-between gap-4">
                  <div className="space-y-1.5 flex-1">
                    <div className="flex items-center gap-2 text-xs">
                      <span className={`font-mono font-bold text-[11px] px-2 py-0.5 rounded ${
                        finding.severity === 'Critical' ? 'bg-rose-950 text-rose-300 border border-rose-800' :
                        finding.severity === 'High' ? 'bg-amber-950 text-amber-300 border border-amber-800' :
                        'bg-blue-950 text-blue-300 border border-blue-800'
                      }`}>
                        {finding.severity.toUpperCase()}
                      </span>
                      <span className="font-semibold text-slate-100">{finding.vendorName}</span>
                      <span className="text-slate-400" aria-hidden="true">·</span>
                      <span className="text-slate-400 text-[11px]">Source: {finding.source}</span>
                      <span className="text-slate-400" aria-hidden="true">·</span>
                      <span className="text-slate-400 font-mono text-[11px]">ID: {finding.id}</span>
                    </div>

                    <h3 className="text-sm font-semibold text-white">{finding.title}</h3>
                    <p className="text-xs text-slate-300 leading-relaxed">{finding.description}</p>
                  </div>

                  <div className="text-right shrink-0">
                    <div className="flex items-center gap-1.5 justify-end font-mono text-xs">
                      <Clock className="w-3.5 h-3.5 text-slate-400" />
                      <span className={`font-bold ${
                        isResolved ? 'text-slate-400' :
                        finding.slaDaysRemaining <= 3 ? 'text-rose-400' :
                        finding.slaDaysRemaining <= 15 ? 'text-amber-400' : 'text-slate-300'
                      }`}>
                        {isResolved ? 'Resolved' : `${finding.slaDaysRemaining} Days SLA Left`}
                      </span>
                    </div>
                    <span className="text-[11px] text-slate-400 block font-mono mt-0.5">
                      Target Due: {finding.dueDate}
                    </span>
                  </div>
                </div>

                {/* Plan & Compensating Control Container */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs bg-slate-950/60 p-3.5 rounded-lg border border-slate-800/80">
                  <div className="space-y-1">
                    <span className="text-slate-400 font-medium block">Committed Remediation Plan:</span>
                    <p className="text-slate-200">{finding.remediationPlan || 'Pending vendor formal submission.'}</p>
                  </div>

                  <div className="space-y-1">
                    <span className="text-slate-400 font-medium block">Interim Compensating Control:</span>
                    <p className="text-emerald-400/90">{finding.compensatingControl || 'None specified. Direct exposure until patch deployment.'}</p>
                  </div>
                </div>

                {/* Card Actions */}
                <div className="flex items-center justify-between pt-2 border-t border-slate-800/60 text-xs">
                  <div className="text-slate-400">
                    Assigned: <strong className="text-slate-300">{finding.assignedTo}</strong>
                  </div>

                  <div className="flex items-center gap-2">
                    {!isResolved && (
                      <>
                        <button
                          onClick={() => handleSendReminder(finding.vendorName)}
                          className="px-2.5 py-1 text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded border border-slate-700 transition-colors flex items-center gap-1 cursor-pointer"
                        >
                          <Send className="w-3 h-3 text-slate-400" />
                          <span>Escalate SLA</span>
                        </button>
                        <button
                          onClick={() => setRiskAcceptModalFinding(finding)}
                          className="px-2.5 py-1 text-amber-300 hover:text-white bg-amber-950/40 hover:bg-amber-900/60 rounded border border-amber-800/60 transition-colors cursor-pointer"
                        >
                          Accept Risk
                        </button>
                        <button
                          onClick={() => onResolveFinding(finding.id)}
                          className="px-3 py-1 text-emerald-300 hover:text-white bg-emerald-950/60 hover:bg-emerald-900/80 rounded border border-emerald-800/80 transition-colors flex items-center gap-1 cursor-pointer font-medium"
                        >
                          <Check className="w-3.5 h-3.5" />
                          <span>Mark Resolved</span>
                        </button>
                      </>
                    )}
                    {isResolved && (
                      <span className="text-emerald-400 font-mono flex items-center gap-1">
                        <CheckCircle2 className="w-4 h-4" />
                        Remediation Verified
                      </span>
                    )}
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Accept Risk Sub-Modal */}
      {riskAcceptModalFinding && (
        <div className="fixed inset-0 z-60 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 max-w-lg w-full space-y-4 shadow-2xl">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <h3 className="text-sm font-bold text-white">Formal Risk Acceptance Approval</h3>
              <button onClick={() => setRiskAcceptModalFinding(null)} className="text-slate-400 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="text-xs text-slate-300 space-y-2">
              <p>
                Under OCC Bulletin 2013-29, accepting risk on a third-party deficiency requires documented executive justification and verified compensating controls.
              </p>
              <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 font-mono text-[11px] text-amber-300">
                Finding: {riskAcceptModalFinding.title} ({riskAcceptModalFinding.vendorName})
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-medium text-slate-200 block">
                CISO / Risk Committee Justification:
              </label>
              <textarea
                rows={3}
                placeholder="Document business rationale and active compensating security controls..."
                value={justificationText}
                onChange={(e) => setJustificationText(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-3 text-xs text-slate-100 placeholder-slate-400 focus:outline-none focus:border-cyan-500"
              />
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-800">
              <button
                onClick={() => setRiskAcceptModalFinding(null)}
                className="px-3 py-1.5 text-xs text-slate-400 hover:text-white"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  onAcceptRisk(riskAcceptModalFinding.id, justificationText);
                  setRiskAcceptModalFinding(null);
                  setJustificationText('');
                }}
                className="px-4 py-1.5 text-xs font-medium text-white bg-amber-600 hover:bg-amber-500 rounded-lg"
              >
                Approve Risk Exemption
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
