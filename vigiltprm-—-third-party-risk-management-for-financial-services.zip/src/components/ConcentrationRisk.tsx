import React, { useState } from 'react';
import { 
  Network, 
  AlertTriangle, 
  Server, 
  ShieldCheck, 
  Globe, 
  Cloud, 
  Lock, 
  ChevronRight,
  Info
} from 'lucide-react';
import { Vendor } from '../types/tprm';

interface ConcentrationRiskProps {
  vendors: Vendor[];
  onSelectVendor: (vendor: Vendor) => void;
}

export const ConcentrationRisk: React.FC<ConcentrationRiskProps> = ({
  vendors,
  onSelectVendor
}) => {
  const [selectedProvider, setSelectedProvider] = useState<string | null>(null);

  // Group 4th party dependencies across all vendors
  const providerStats = [
    {
      name: 'Amazon Web Services (AWS)',
      category: 'Cloud Infrastructure',
      vendorCount: 6,
      tier1Count: 4,
      criticality: 'Critical High',
      primaryRegion: 'us-east-1 (N. Virginia), us-west-2 (Oregon)',
      spofRisk: 'Extreme',
      spofNote: 'Synchronous outage in us-east-1 would degrade both Synapse Payments and Veritas IAM simultaneously.',
      vendorsDependent: ['Synapse Payments Gateway', 'Apex Data Cloud & Analytics', 'Veritas Identity & Access (IAM)', 'Kallisto Enterprise CRM', 'Veloce Employee Collaboration']
    },
    {
      name: 'Cloudflare',
      category: 'CDN & DDoS Edge',
      vendorCount: 5,
      tier1Count: 3,
      criticality: 'High',
      primaryRegion: 'Global Anycast Edge Network',
      spofRisk: 'Moderate',
      spofNote: 'Edge routing failure triggers automated failover to alternate DNS, but API edge rate limiting would be impacted.',
      vendorsDependent: ['Synapse Payments Gateway', 'Aegis Core Banking Systems', 'Apex Data Cloud & Analytics']
    },
    {
      name: 'Okta Identity Cloud',
      category: 'Identity & IAM',
      vendorCount: 4,
      tier1Count: 3,
      criticality: 'High',
      primaryRegion: 'US Multi-Region Cell',
      spofRisk: 'High',
      spofNote: 'Authentication degradation locks vendor administrators out of emergency production access consoles.',
      vendorsDependent: ['Synapse Payments Gateway', 'Veritas Identity & Access (IAM)', 'Aegis Core Banking Systems']
    },
    {
      name: 'Equinix Colocation Centers',
      category: 'Physical Datacenter & DirectConnect',
      vendorCount: 2,
      tier1Count: 2,
      criticality: 'High',
      primaryRegion: 'NY4 (Secaucus NJ) & DC11 (Ashburn VA)',
      spofRisk: 'Low (N+2 Redundancy)',
      spofNote: 'Dual-site active-active deployment maintains 99.999% SLA across regional power feeds.',
      vendorsDependent: ['Aegis Core Banking Systems', 'Prism Treasury Management']
    },
    {
      name: 'Google Cloud Platform (GCP)',
      category: 'Cloud Infrastructure & BigQuery',
      vendorCount: 2,
      tier1Count: 1,
      criticality: 'Moderate',
      primaryRegion: 'us-central1 (Iowa), europe-west3 (Frankfurt)',
      spofRisk: 'Moderate',
      spofNote: 'Hosts core risk and Basel III analytics algorithms. Non-intraday recovery window is 4 hours.',
      vendorsDependent: ['Apex Data Cloud & Analytics']
    },
    {
      name: 'Microsoft Azure',
      category: 'Cloud Infrastructure',
      vendorCount: 2,
      tier1Count: 1,
      criticality: 'Moderate',
      primaryRegion: 'East US 2 & West Europe',
      spofRisk: 'Moderate',
      spofNote: 'Hosts real-time AML sanctions and PEP scanning.',
      vendorsDependent: ['Sentinel AML & Sanctions Radar']
    }
  ];

  return (
    <div className="p-8 space-y-6 max-w-7xl mx-auto">
      {/* Title Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-white flex items-center gap-2">
            <Network className="w-5 h-5 text-cyan-400" />
            <span>4th-Party Concentration Risk & Supply Chain Dependencies</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Mandated analysis under OCC Bulletin 2013-29 §V and EU DORA Article 28(2) identifying shared systemic points of failure
          </p>
        </div>
      </div>

      {/* Single Point of Failure (SPOF) Callout Banner */}
      <div className="p-5 rounded-xl bg-amber-950/40 border border-amber-800/80 flex items-start gap-4">
        <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
        <div className="space-y-1">
          <h3 className="text-xs font-bold text-amber-200 uppercase tracking-wider">
            Critical Concentration Warning: Hyper-scaler Multi-Vendor Overlap
          </h3>
          <p className="text-xs text-amber-300/90 leading-relaxed">
            <strong>75% of Tier 1 mission-critical vendors</strong> share underlying dependency on Amazon Web Services (AWS us-east-1 and us-west-2). A cascading cloud provider service disruption would impact core settlement, payments processing, and identity directory operations simultaneously.
          </p>
          <div className="pt-2 text-[11px] text-amber-400 font-mono">
            Regulatory Directive: Annual secondary failover simulation required under DORA Article 11.
          </div>
        </div>
      </div>

      {/* Cloud & Infrastructure Breakdown Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="p-5 bg-slate-900 border border-slate-800 rounded-xl space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-200">Cloud Hyper-scaler Share</span>
            <Cloud className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="space-y-2 text-xs">
            <div>
              <div className="flex justify-between text-slate-300 font-mono mb-1">
                <span>Amazon Web Services</span>
                <span>62%</span>
              </div>
              <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                <div className="h-full bg-cyan-500 rounded-full" style={{ width: '62%' }} />
              </div>
            </div>
            <div>
              <div className="flex justify-between text-slate-300 font-mono mb-1">
                <span>Google Cloud Platform</span>
                <span>24%</span>
              </div>
              <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                <div className="h-full bg-blue-500 rounded-full" style={{ width: '24%' }} />
              </div>
            </div>
            <div>
              <div className="flex justify-between text-slate-300 font-mono mb-1">
                <span>Microsoft Azure</span>
                <span>14%</span>
              </div>
              <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                <div className="h-full bg-indigo-500 rounded-full" style={{ width: '14%' }} />
              </div>
            </div>
          </div>
        </div>

        <div className="p-5 bg-slate-900 border border-slate-800 rounded-xl space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-200">Edge & Identity Dominance</span>
            <Lock className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="space-y-2 text-xs">
            <div>
              <div className="flex justify-between text-slate-300 font-mono mb-1">
                <span>Cloudflare Edge Protection</span>
                <span>58%</span>
              </div>
              <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                <div className="h-full bg-emerald-500 rounded-full" style={{ width: '58%' }} />
              </div>
            </div>
            <div>
              <div className="flex justify-between text-slate-300 font-mono mb-1">
                <span>Okta Workforce IAM</span>
                <span>45%</span>
              </div>
              <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                <div className="h-full bg-teal-500 rounded-full" style={{ width: '45%' }} />
              </div>
            </div>
            <div>
              <div className="flex justify-between text-slate-300 font-mono mb-1">
                <span>Equinix Interconnect</span>
                <span>18%</span>
              </div>
              <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                <div className="h-full bg-slate-500 rounded-full" style={{ width: '18%' }} />
              </div>
            </div>
          </div>
        </div>

        <div className="p-5 bg-slate-900 border border-slate-800 rounded-xl space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-200">Data Sovereignty & Regions</span>
            <Globe className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="space-y-2 text-xs">
            <div>
              <div className="flex justify-between text-slate-300 font-mono mb-1">
                <span>United States (NPI & General)</span>
                <span>82%</span>
              </div>
              <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                <div className="h-full bg-cyan-500 rounded-full" style={{ width: '82%' }} />
              </div>
            </div>
            <div>
              <div className="flex justify-between text-slate-300 font-mono mb-1">
                <span>European Union (DORA / GDPR)</span>
                <span>14%</span>
              </div>
              <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                <div className="h-full bg-purple-500 rounded-full" style={{ width: '14%' }} />
              </div>
            </div>
            <div>
              <div className="flex justify-between text-slate-300 font-mono mb-1">
                <span>Switzerland (Private Colocation)</span>
                <span>4%</span>
              </div>
              <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                <div className="h-full bg-slate-400 rounded-full" style={{ width: '4%' }} />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Detailed Concentration Register Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-sm">
        <div className="p-4 bg-slate-950/60 border-b border-slate-800 flex items-center justify-between">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-300">
            Material 4th-Party Concentration Register
          </h3>
          <span className="text-xs text-slate-400 font-mono">DORA Article 28 Information Register</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="text-slate-400 border-b border-slate-800 bg-slate-950/30 font-medium">
                <th className="py-3 px-4">Upstream Infrastructure Provider</th>
                <th className="py-3 px-3">Service Category</th>
                <th className="py-3 px-3 text-center">Dependent Vendors</th>
                <th className="py-3 px-3 text-center">Tier 1 Overlap</th>
                <th className="py-3 px-3">Primary Geographic Deployment</th>
                <th className="py-3 px-3">Concentration Vulnerability Note</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {providerStats.map((item) => (
                <tr key={item.name} className="hover:bg-slate-800/40 transition-colors">
                  <td className="py-3.5 px-4">
                    <div className="font-semibold text-slate-100">{item.name}</div>
                    <div className="text-[11px] text-slate-400 mt-0.5">
                      {item.vendorsDependent.slice(0, 2).join(', ')}
                      {item.vendorsDependent.length > 2 && ` +${item.vendorsDependent.length - 2} more`}
                    </div>
                  </td>
                  <td className="py-3.5 px-3 text-slate-300">{item.category}</td>
                  <td className="py-3.5 px-3 text-center font-mono tabular-nums text-slate-200 font-bold">
                    {item.vendorCount}
                  </td>
                  <td className="py-3.5 px-3 text-center">
                    <span className="font-mono text-rose-400 font-bold text-xs bg-rose-950/60 px-2 py-0.5 rounded border border-rose-900/60">
                      {item.tier1Count} Critical
                    </span>
                  </td>
                  <td className="py-3.5 px-3 text-slate-300 font-mono text-[11px]">
                    {item.primaryRegion}
                  </td>
                  <td className="py-3.5 px-3 text-slate-400 max-w-sm text-[11px] leading-relaxed">
                    {item.spofNote}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
