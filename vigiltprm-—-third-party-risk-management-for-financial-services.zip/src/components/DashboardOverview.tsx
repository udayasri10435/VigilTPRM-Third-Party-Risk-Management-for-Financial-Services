import React from 'react';
import { 
  Building2, 
  AlertOctagon, 
  TrendingUp, 
  Activity, 
  FileCheck, 
  ChevronRight,
  Shield,
  Layers,
  CheckCircle2,
  ExternalLink
} from 'lucide-react';
import { Vendor, MonitoringAlert, Finding, InstitutionProfile } from '../types/tprm';

interface DashboardOverviewProps {
  vendors: Vendor[];
  alerts: MonitoringAlert[];
  findings: Finding[];
  institution: InstitutionProfile;
  onSelectVendor: (vendor: Vendor) => void;
  onNavigateTab: (tab: string) => void;
  onAcknowledgeAlert: (alertId: string) => void;
}

export const DashboardOverview: React.FC<DashboardOverviewProps> = ({
  vendors,
  alerts,
  findings,
  institution,
  onSelectVendor,
  onNavigateTab,
  onAcknowledgeAlert
}) => {
  const tier1Vendors = vendors.filter(v => v.tier === 'Tier 1');
  const totalAnnualSpend = vendors.reduce((sum, v) => sum + v.annualSpendUsd, 0);
  const avgSecurityScore = Math.round(vendors.reduce((sum, v) => sum + v.securityScore, 0) / (vendors.length || 1));
  const openCriticalFindings = findings.filter(f => f.severity === 'Critical' && f.status !== 'Resolved');
  const urgentAlerts = alerts.filter(a => a.severity === 'Critical' || a.severity === 'High');

  // Grade breakdown
  const gradeCounts = {
    A: vendors.filter(v => v.scoreGrade === 'A').length,
    B: vendors.filter(v => v.scoreGrade === 'B').length,
    C: vendors.filter(v => v.scoreGrade === 'C').length,
    D: vendors.filter(v => v.scoreGrade === 'D').length,
    F: vendors.filter(v => v.scoreGrade === 'F').length,
  };

  return (
    <div className="p-8 space-y-8 max-w-7xl mx-auto">
      {/* Executive KPI Strip */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* KPI 1 */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-medium uppercase tracking-wider">Tier 1 Mission Critical</span>
            <Building2 className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-semibold text-white font-mono tabular-nums">{tier1Vendors.length}</span>
            <span className="text-xs text-slate-400">of {vendors.length} total vendors</span>
          </div>
          <div className="mt-3 pt-3 border-t border-slate-800/80 flex items-center justify-between text-xs text-slate-400">
            <span>Annual Portfolio Spend</span>
            <span className="font-mono text-slate-200 font-medium">${(totalAnnualSpend / 1_000_000).toFixed(1)}M USD</span>
          </div>
        </div>

        {/* KPI 2 */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-medium uppercase tracking-wider">Avg Residual Risk</span>
            <Shield className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-semibold text-emerald-400 font-mono tabular-nums">{institution.averageResidualRisk}</span>
            <span className="text-xs text-slate-400">/ 25.0 scale</span>
          </div>
          <div className="mt-3 pt-3 border-t border-slate-800/80 flex items-center justify-between text-xs text-slate-400">
            <span>Inherent Risk Offset</span>
            <span className="text-emerald-400 font-medium font-mono">-64% via Controls</span>
          </div>
        </div>

        {/* KPI 3 */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-medium uppercase tracking-wider">Fleet Security Posture</span>
            <Activity className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-semibold text-white font-mono tabular-nums">{avgSecurityScore}</span>
            <span className="text-xs text-slate-400">/ 100 Index</span>
          </div>
          <div className="mt-3 pt-3 border-t border-slate-800/80 flex items-center justify-between text-xs text-slate-400">
            <span>Credit Score Equivalent</span>
            <span className="font-mono text-cyan-300 font-medium">768 / 850</span>
          </div>
        </div>

        {/* KPI 4 */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-medium uppercase tracking-wider">Critical SLA Deficiencies</span>
            <AlertOctagon className="w-4 h-4 text-rose-400" />
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-semibold text-rose-400 font-mono tabular-nums">{openCriticalFindings.length}</span>
            <span className="text-xs text-slate-400">Open Actions</span>
          </div>
          <div className="mt-3 pt-3 border-t border-slate-800/80 flex items-center justify-between text-xs text-slate-400">
            <span>Shortest SLA Deadline</span>
            <span className="text-rose-300 font-medium font-mono">2 Days (Aegis)</span>
          </div>
        </div>
      </div>

      {/* Main Grid: Live Monitoring Alerts & Risk Distribution */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Continuous Monitoring Radar Feed (2 Cols) */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-sm">
          <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-800">
            <div>
              <h3 className="text-sm font-semibold text-white flex items-center gap-2">
                <Activity className="w-4 h-4 text-cyan-400" />
                <span>Continuous Threat & Posture Alerts</span>
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">Real-time external attack surface, CVE vulnerabilities, and regulatory triggers</p>
            </div>
            <button
              onClick={() => onNavigateTab('monitoring')}
              className="text-xs text-cyan-400 hover:text-cyan-300 flex items-center gap-1 font-medium cursor-pointer"
            >
              <span>View Full Radar</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="space-y-3">
            {urgentAlerts.map(alert => (
              <div 
                key={alert.id}
                className="p-4 rounded-lg bg-slate-950/70 border border-slate-800/90 hover:border-slate-700 transition-colors flex flex-col md:flex-row md:items-center justify-between gap-4"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2 text-xs">
                    <span className={`font-mono font-medium text-[11px] ${
                      alert.severity === 'Critical' ? 'text-rose-400' :
                      alert.severity === 'High' ? 'text-amber-400' : 'text-blue-400'
                    }`}>
                      [{alert.severity.toUpperCase()}]
                    </span>
                    <span className="font-semibold text-slate-200">{alert.vendorName}</span>
                    <span className="text-slate-400" aria-hidden="true">·</span>
                    <span className="text-slate-400 font-mono text-[11px]">{alert.tier}</span>
                    <span className="text-slate-400" aria-hidden="true">·</span>
                    <span className="text-slate-400 text-[11px]">{alert.timestamp}</span>
                  </div>
                  <h4 className="text-sm font-medium text-slate-100">{alert.title}</h4>
                  <p className="text-xs text-slate-400 line-clamp-1">{alert.detail}</p>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <span className="text-xs font-mono text-rose-400 bg-rose-950/40 border border-rose-900/50 px-2 py-1 rounded">
                    Score Impact: {alert.impactScoreChange}
                  </span>
                  <button
                    onClick={() => onAcknowledgeAlert(alert.id)}
                    className="px-2.5 py-1 text-xs font-medium text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded transition-colors cursor-pointer"
                  >
                    Action Plan
                  </button>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-4 pt-3 border-t border-slate-800/60 flex items-center justify-between text-xs text-slate-400">
            <span>Automated Daily Recon: 1,420 Hostnames, 28 IP Blocks, 12 Certificate Authorities monitored</span>
            <span className="text-cyan-400 font-mono">Last Scan: 14 mins ago</span>
          </div>
        </div>

        {/* Security Posture Grade Breakdown (1 Col) */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-800">
              <h3 className="text-sm font-semibold text-white">Vendor Posture Distribution</h3>
              <span className="text-xs text-slate-400">External Rating</span>
            </div>

            <div className="space-y-3">
              {[
                { grade: 'A', label: 'Exceptional (90-100)', count: gradeCounts.A, color: 'bg-emerald-500', text: 'text-emerald-400' },
                { grade: 'B', label: 'Good Assurance (80-89)', count: gradeCounts.B, color: 'bg-cyan-500', text: 'text-cyan-400' },
                { grade: 'C', label: 'Fair / Monitored (70-79)', count: gradeCounts.C, color: 'bg-amber-500', text: 'text-amber-400' },
                { grade: 'D', label: 'Elevated Risk (60-69)', count: gradeCounts.D, color: 'bg-orange-500', text: 'text-orange-400' },
                { grade: 'F', label: 'Critical Risk (< 60)', count: gradeCounts.F, color: 'bg-rose-500', text: 'text-rose-400' },
              ].map(item => {
                const percentage = Math.round((item.count / vendors.length) * 100);
                return (
                  <div key={item.grade} className="space-y-1">
                    <div className="flex items-center justify-between text-xs">
                      <div className="flex items-center gap-2">
                        <span className={`font-mono font-bold text-xs ${item.text}`}>Grade {item.grade}</span>
                        <span className="text-slate-400 text-[11px]">{item.label}</span>
                      </div>
                      <span className="font-mono text-slate-200 tabular-nums">{item.count} ({percentage}%)</span>
                    </div>
                    <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                      <div 
                        className={`h-full ${item.color} rounded-full transition-all duration-500`}
                        style={{ width: `${percentage}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="mt-6 pt-4 border-t border-slate-800 text-xs text-slate-400">
            <p className="leading-relaxed">
              Tier 1 vendors falling below Grade C trigger mandatory remediation under OCC Bulletin 2013-29 §IV.
            </p>
          </div>
        </div>
      </div>

      {/* Inherent vs Residual Risk Matrix & Regulatory Compliance Meters */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Risk Matrix Quadrant (2 Cols) */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-sm">
          <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-800">
            <div>
              <h3 className="text-sm font-semibold text-white flex items-center gap-2">
                <Layers className="w-4 h-4 text-cyan-400" />
                <span>Inherent vs. Residual Risk Matrix (5x5)</span>
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">Measurement of risk pre-controls (Inherent) vs. post-questionnaire assurance (Residual)</p>
            </div>
            <span className="text-xs text-slate-400 font-mono">OCC Interagency Model</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-4 bg-slate-950/60 border border-slate-800 rounded-lg">
              <div className="flex items-center justify-between text-xs mb-3 text-slate-300">
                <span className="font-medium">Inherent Risk (Exposure)</span>
                <span className="font-mono text-amber-400">High Exposure Fleet</span>
              </div>
              <p className="text-xs text-slate-400 mb-3 leading-relaxed">
                Evaluates business criticality, volume of non-public personal information (NPI), and operational dependency before assessing vendor defenses.
              </p>
              <div className="space-y-2">
                {vendors.slice(0, 3).map(v => (
                  <div key={v.id} className="flex items-center justify-between text-xs py-1 border-b border-slate-800/60">
                    <span className="text-slate-300 truncate max-w-[160px]">{v.name}</span>
                    <div className="flex items-center gap-2">
                      <span className="text-[11px] text-slate-400 font-mono">{v.tier}</span>
                      <span className="font-mono font-medium text-amber-400 tabular-nums">{v.inherentRiskScore}/25</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="p-4 bg-slate-950/60 border border-slate-800 rounded-lg">
              <div className="flex items-center justify-between text-xs mb-3 text-slate-300">
                <span className="font-medium">Residual Risk (Post-Mitigation)</span>
                <span className="font-mono text-emerald-400">Within Bank Risk Appetite</span>
              </div>
              <p className="text-xs text-slate-400 mb-3 leading-relaxed">
                Calculated by subtracting SIG Lite security scores, SOC 2 audit verifications, and contractual remedies from inherent risk.
              </p>
              <div className="space-y-2">
                {vendors.slice(0, 3).map(v => (
                  <div key={v.id} className="flex items-center justify-between text-xs py-1 border-b border-slate-800/60">
                    <span className="text-slate-300 truncate max-w-[160px]">{v.name}</span>
                    <div className="flex items-center gap-2">
                      <span className={`font-mono font-medium tabular-nums ${
                        v.residualRiskScore > 12 ? 'text-rose-400' :
                        v.residualRiskScore > 8 ? 'text-amber-400' : 'text-emerald-400'
                      }`}>
                        {v.residualRiskScore}/25
                      </span>
                      <span className="text-[10px] text-slate-400">
                        {v.residualRiskScore > 12 ? 'Elevated' : v.residualRiskScore > 8 ? 'Moderate' : 'Low'}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Regulatory Governance Alignment (1 Col) */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-800">
              <h3 className="text-sm font-semibold text-white">Regulatory Coverage</h3>
              <span className="text-xs text-emerald-400 font-mono">100% Audited</span>
            </div>

            <div className="space-y-3.5">
              {[
                { name: 'OCC 2023-29 Interagency Bulletin', status: 'Compliant', coverage: '42 / 42 Vendors', icon: CheckCircle2 },
                { name: 'EU DORA (Digital Operational Resilience)', status: 'Active Register', coverage: '8 / 8 ICT Vendors', icon: CheckCircle2 },
                { name: 'NYDFS 23 NYCRR 500.11 (TPRM)', status: 'Annual Review Complete', coverage: 'All NPI Custodians', icon: CheckCircle2 },
                { name: 'PCI-DSS v4.0 Requirement 12.8', status: 'AoC Verified', coverage: '100% Payment Rails', icon: CheckCircle2 },
              ].map(item => {
                const Icon = item.icon;
                return (
                  <div key={item.name} className="flex items-start gap-3 p-2.5 rounded-lg bg-slate-950/40 border border-slate-800/60">
                    <Icon className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                    <div className="space-y-0.5">
                      <p className="text-xs font-medium text-slate-200">{item.name}</p>
                      <div className="flex items-center gap-2 text-[11px] text-slate-400">
                        <span className="text-emerald-400">{item.status}</span>
                        <span aria-hidden="true">·</span>
                        <span>{item.coverage}</span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <button
            onClick={() => onNavigateTab('reports')}
            className="mt-4 w-full py-2 px-3 text-xs font-medium text-slate-200 hover:text-white bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-lg transition-colors flex items-center justify-center gap-2 cursor-pointer"
          >
            <span>Generate Regulatory Audit Pack</span>
            <ExternalLink className="w-3.5 h-3.5 text-slate-400" />
          </button>
        </div>
      </div>

      {/* Tier 1 Priority Focus Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-sm">
        <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-800">
          <div>
            <h3 className="text-sm font-semibold text-white">Tier 1 Mission-Critical Service Providers</h3>
            <p className="text-xs text-slate-400 mt-0.5">Vendors supporting core processing, wire rails, and sensitive non-public data repositories</p>
          </div>
          <button
            onClick={() => onNavigateTab('vendors')}
            className="text-xs text-cyan-400 hover:text-cyan-300 font-medium cursor-pointer"
          >
            View All Vendors →
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="text-slate-400 border-b border-slate-800 font-medium">
                <th className="pb-3 pl-2">Vendor Name</th>
                <th className="pb-3">Primary Category</th>
                <th className="pb-3 text-center">Score Grade</th>
                <th className="pb-3 text-center">Continuous Score</th>
                <th className="pb-3 text-center">Inherent / Residual</th>
                <th className="pb-3">Open Findings</th>
                <th className="pb-3">Next Renewal</th>
                <th className="pb-3 text-right pr-2">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {tier1Vendors.map(vendor => (
                <tr key={vendor.id} className="hover:bg-slate-800/40 transition-colors">
                  <td className="py-3 pl-2">
                    <div className="font-semibold text-slate-200">{vendor.name}</div>
                    <div className="text-[11px] text-slate-400 font-mono">{vendor.domain}</div>
                  </td>
                  <td className="py-3 text-slate-300">{vendor.primaryCategory}</td>
                  <td className="py-3 text-center">
                    <span className={`inline-block font-mono font-bold px-2 py-0.5 rounded text-xs ${
                      vendor.scoreGrade === 'A' ? 'bg-emerald-950/60 text-emerald-400 border border-emerald-800/60' :
                      vendor.scoreGrade === 'B' ? 'bg-cyan-950/60 text-cyan-400 border border-cyan-800/60' :
                      vendor.scoreGrade === 'C' ? 'bg-amber-950/60 text-amber-400 border border-amber-800/60' :
                      'bg-rose-950/60 text-rose-400 border border-rose-800/60'
                    }`}>
                      {vendor.scoreGrade}
                    </span>
                  </td>
                  <td className="py-3 text-center font-mono tabular-nums text-slate-200 font-medium">
                    {vendor.securityScore}/100
                    <span className="text-[10px] text-slate-400 block font-normal">({vendor.creditStyleScore})</span>
                  </td>
                  <td className="py-3 text-center font-mono tabular-nums">
                    <span className="text-amber-400">{vendor.inherentRiskScore}</span>
                    <span className="text-slate-400 mx-1">→</span>
                    <span className={`font-semibold ${
                      vendor.residualRiskScore > 12 ? 'text-rose-400' :
                      vendor.residualRiskScore > 8 ? 'text-amber-400' : 'text-emerald-400'
                    }`}>
                      {vendor.residualRiskScore}
                    </span>
                  </td>
                  <td className="py-3">
                    {vendor.activeFindingsCount.critical > 0 ? (
                      <span className="text-rose-400 font-mono font-semibold flex items-center gap-1">
                        <AlertOctagon className="w-3.5 h-3.5" />
                        {vendor.activeFindingsCount.critical} Critical
                      </span>
                    ) : vendor.activeFindingsCount.high > 0 ? (
                      <span className="text-amber-400 font-mono">
                        {vendor.activeFindingsCount.high} High
                      </span>
                    ) : (
                      <span className="text-emerald-400 text-[11px] flex items-center gap-1">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        Zero Open
                      </span>
                    )}
                  </td>
                  <td className="py-3 font-mono text-slate-400 text-[11px]">{vendor.contractRenewalDate}</td>
                  <td className="py-3 text-right pr-2">
                    <button
                      onClick={() => onSelectVendor(vendor)}
                      className="px-2.5 py-1 text-xs font-medium text-cyan-300 hover:text-white bg-cyan-950/60 hover:bg-cyan-900/80 border border-cyan-800/60 rounded transition-colors cursor-pointer"
                    >
                      Dossier
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
