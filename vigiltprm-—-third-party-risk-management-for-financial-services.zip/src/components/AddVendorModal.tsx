import React, { useState } from 'react';
import { 
  X, 
  Building2, 
  ShieldCheck, 
  Activity, 
  Search, 
  Check, 
  ChevronRight, 
  CheckCircle2, 
  AlertCircle,
  Send,
  Loader2
} from 'lucide-react';
import { Vendor, RiskTier, CriticalityLevel, DataClassification, RegulatoryFramework } from '../types/tprm';
import { standardSigLiteSections } from '../data/questionnaires';

interface AddVendorModalProps {
  onClose: () => void;
  onAddVendor: (newVendor: Vendor) => void;
}

export const AddVendorModal: React.FC<AddVendorModalProps> = ({
  onClose,
  onAddVendor
}) => {
  const [step, setStep] = useState<1 | 2 | 3>(1);

  // Form State
  const [name, setName] = useState('');
  const [domain, setDomain] = useState('');
  const [primaryCategory, setPrimaryCategory] = useState('Core Account & Ledger Ledger Engine');
  const [businessOwner, setBusinessOwner] = useState('Elena Rostova (TPRM)');
  const [annualSpend, setAnnualSpend] = useState('1250000');
  const [contactEmail, setContactEmail] = useState('');
  const [description, setDescription] = useState('');
  
  // Inherent risk factors
  const [selectedDataClasses, setSelectedDataClasses] = useState<DataClassification[]>(['NPI / PII']);
  const [systemAccess, setSystemAccess] = useState<'Core Network' | 'API' | 'SaaS Hosted' | 'Isolated'>('API');
  const [criticality, setCriticality] = useState<CriticalityLevel>('High');

  // Recon scan simulation
  const [isScanning, setIsScanning] = useState(false);
  const [scanCompleted, setScanCompleted] = useState(false);
  const [simulatedScore, setSimulatedScore] = useState(85);
  const [detectedHost, setDetectedHost] = useState('Amazon Web Services (AWS us-east-1)');

  // Calculate Inherent Risk based on inputs
  const calculatedInherentRisk = (() => {
    let base = 10;
    if (selectedDataClasses.includes('NPI / PII')) base += 5;
    if (selectedDataClasses.includes('Cardholder Data (CHD)')) base += 5;
    if (systemAccess === 'Core Network') base += 5;
    else if (systemAccess === 'API') base += 3;
    if (criticality === 'Mission Critical') base += 5;
    return Math.min(25, base);
  })();

  const recommendedTier: RiskTier = calculatedInherentRisk >= 20 ? 'Tier 1' : calculatedInherentRisk >= 14 ? 'Tier 2' : 'Tier 3';

  const handleStartScan = () => {
    if (!domain) return;
    setIsScanning(true);
    setTimeout(() => {
      setIsScanning(false);
      setScanCompleted(true);
      const score = Math.floor(Math.random() * 15) + 82; // 82 to 97
      setSimulatedScore(score);
      setDetectedHost(domain.includes('cloud') ? 'Google Cloud Platform (GCP)' : 'Amazon Web Services (AWS us-east-1)');
    }, 1800);
  };

  const handleCreateVendor = () => {
    const newVendor: Vendor = {
      id: `ven-${Date.now().toString().slice(-4)}`,
      name: name || 'New Enterprise Vendor',
      domain: domain || 'vendor-domain.com',
      tier: recommendedTier,
      status: 'Onboarding',
      criticality,
      primaryCategory,
      businessOwner,
      tprAnalyst: 'Devon Cross (Senior TPRM Analyst)',
      annualSpendUsd: parseInt(annualSpend) || 500000,
      contractStartDate: new Date().toISOString().split('T')[0],
      contractRenewalDate: '2027-10-01',
      hostingLocation: detectedHost,
      dataClassifications: selectedDataClasses,
      applicableFrameworks: ['OCC 2023-29', 'SOC 2 Type II', 'DORA'],
      securityScore: simulatedScore,
      scoreGrade: simulatedScore >= 90 ? 'A' : simulatedScore >= 80 ? 'B' : 'C',
      creditStyleScore: Math.round(300 + (simulatedScore / 100) * 550),
      scoreTrend30d: 0,
      inherentRiskScore: calculatedInherentRisk,
      residualRiskScore: Math.max(4, Math.round(calculatedInherentRisk * 0.4)),
      vectorScores: {
        networkSecurity: simulatedScore,
        patchCadence: Math.min(100, simulatedScore + 2),
        applicationSecurity: Math.max(70, simulatedScore - 4),
        dnsEmailHygiene: 92,
        darkWebExposure: 88,
        endpointHygiene: 85,
        complianceAttestation: 80
      },
      activeFindingsCount: { critical: 0, high: 0, medium: 0, low: 0 },
      questionnaires: [
        {
          id: `q-${Date.now()}`,
          vendorId: `ven-${Date.now().toString().slice(-4)}`,
          vendorName: name || 'New Enterprise Vendor',
          title: `Initial ${recommendedTier} SIG Lite Assessment`,
          standard: 'SIG Lite',
          status: 'Sent to Vendor',
          completionRate: 0,
          overallScore: 0,
          dueDate: '2026-10-31',
          lastUpdated: new Date().toISOString().split('T')[0],
          sections: JSON.parse(JSON.stringify(standardSigLiteSections))
        }
      ],
      documents: [],
      fourthParties: [
        {
          name: detectedHost.includes('AWS') ? 'Amazon Web Services (AWS)' : 'Google Cloud Platform (GCP)',
          category: 'Cloud Infrastructure',
          provider: detectedHost,
          region: 'United States',
          riskLevel: recommendedTier === 'Tier 1' ? 'High' : 'Medium',
          notes: 'Auto-detected infrastructure host during initial DNS reconnaissance.'
        }
      ],
      recentAlerts: [],
      description: description || 'New enterprise third-party provider undergoing initial onboarding and inherent risk determination.',
      contactEmail: contactEmail || 'security@vendor.com'
    };

    onAddVendor(newVendor);
    onClose();
  };

  const toggleDataClass = (dc: DataClassification) => {
    if (selectedDataClasses.includes(dc)) {
      setSelectedDataClasses(prev => prev.filter(item => item !== dc));
    } else {
      setSelectedDataClasses(prev => [...prev, dc]);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-2xl shadow-2xl overflow-hidden my-auto">
        {/* Header */}
        <div className="p-6 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
          <div>
            <h2 className="text-lg font-bold text-white tracking-tight">Onboard New Third-Party Vendor</h2>
            <p className="text-xs text-slate-400 mt-0.5">OCC 2023-29 Inherent Risk Assessment & Automated Recon Scan</p>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white p-1 rounded-lg">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Steps Progress */}
        <div className="grid grid-cols-3 border-b border-slate-800 bg-slate-950/40 text-xs">
          <div className={`py-3 px-4 text-center font-medium border-b-2 ${
            step === 1 ? 'border-cyan-500 text-cyan-400' : 'border-transparent text-slate-400'
          }`}>
            1. Vendor Details
          </div>
          <div className={`py-3 px-4 text-center font-medium border-b-2 ${
            step === 2 ? 'border-cyan-500 text-cyan-400' : 'border-transparent text-slate-400'
          }`}>
            2. Inherent Risk & Tier
          </div>
          <div className={`py-3 px-4 text-center font-medium border-b-2 ${
            step === 3 ? 'border-cyan-500 text-cyan-400' : 'border-transparent text-slate-400'
          }`}>
            3. Perimeter Recon & Finalize
          </div>
        </div>

        {/* Body */}
        <div className="p-6 space-y-4 max-h-[60vh] overflow-y-auto text-xs">
          {/* STEP 1 */}
          {step === 1 && (
            <div className="space-y-4">
              <div>
                <label className="text-slate-300 font-medium block mb-1">Legal Vendor Name *</label>
                <input
                  type="text"
                  placeholder="e.g. VaultPay Infrastructure Technologies Inc."
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-slate-100 placeholder-slate-400 focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-slate-300 font-medium block mb-1">Primary Domain *</label>
                  <input
                    type="text"
                    placeholder="e.g. vaultpay.com"
                    value={domain}
                    onChange={(e) => setDomain(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-slate-100 placeholder-slate-400 focus:outline-none focus:border-cyan-500 font-mono text-xs"
                  />
                </div>

                <div>
                  <label className="text-slate-300 font-medium block mb-1">Primary Service Category</label>
                  <select
                    value={primaryCategory}
                    onChange={(e) => setPrimaryCategory(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-slate-100 focus:outline-none focus:border-cyan-500"
                  >
                    <option value="Payment Processing & Clearing">Payment Processing & Clearing</option>
                    <option value="Core Account & Ledger Ledger Engine">Core Account & Ledger Ledger Engine</option>
                    <option value="Enterprise Data Warehouse & ML">Enterprise Data Warehouse & ML</option>
                    <option value="Identity & Access Management (IAM)">Identity & Access Management (IAM)</option>
                    <option value="Financial Crime & AML / KYC">Financial Crime & AML / KYC</option>
                    <option value="Client Relationship & Wealth Advisory">Client Relationship & Wealth Advisory</option>
                    <option value="Enterprise Collaboration & SaaS">Enterprise Collaboration & SaaS</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-slate-300 font-medium block mb-1">Annual Contract Spend ($ USD)</label>
                  <input
                    type="number"
                    value={annualSpend}
                    onChange={(e) => setAnnualSpend(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-slate-100 focus:outline-none focus:border-cyan-500 font-mono"
                  />
                </div>

                <div>
                  <label className="text-slate-300 font-medium block mb-1">Security Contact Email</label>
                  <input
                    type="email"
                    placeholder="grc@vaultpay.com"
                    value={contactEmail}
                    onChange={(e) => setContactEmail(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-slate-100 focus:outline-none focus:border-cyan-500 font-mono text-xs"
                  />
                </div>
              </div>

              <div>
                <label className="text-slate-300 font-medium block mb-1">Description of Service & Bank Business Purpose</label>
                <textarea
                  rows={2}
                  placeholder="Summarize the core business operations and technical integration with bank systems..."
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-slate-100 placeholder-slate-400 focus:outline-none focus:border-cyan-500"
                />
              </div>
            </div>
          )}

          {/* STEP 2 */}
          {step === 2 && (
            <div className="space-y-4">
              <div>
                <label className="text-slate-300 font-medium block mb-2">
                  1. Scope of Bank Data Shared or Handled (Select all that apply):
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {(['NPI / PII', 'Cardholder Data (CHD)', 'Confidential IP', 'Operational Data', 'Public'] as DataClassification[]).map(dc => {
                    const isSelected = selectedDataClasses.includes(dc);
                    return (
                      <button
                        key={dc}
                        type="button"
                        onClick={() => toggleDataClass(dc)}
                        className={`p-2.5 rounded-lg border text-left transition-colors cursor-pointer ${
                          isSelected ? 'bg-cyan-950/80 border-cyan-600 text-cyan-200' : 'bg-slate-950/40 border-slate-800 text-slate-400'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span className="font-semibold">{dc}</span>
                          {isSelected && <Check className="w-3.5 h-3.5 text-cyan-400" />}
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 pt-2">
                <div>
                  <label className="text-slate-300 font-medium block mb-1">2. Network Connectivity</label>
                  <select
                    value={systemAccess}
                    onChange={(e) => setSystemAccess(e.target.value as any)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-slate-100 focus:outline-none focus:border-cyan-500"
                  >
                    <option value="Core Network">Direct VPN / Dedicated Core Network</option>
                    <option value="API">Mutual TLS API Integrations</option>
                    <option value="SaaS Hosted">Multi-tenant Cloud SaaS</option>
                    <option value="Isolated">Isolated / No Bank System Access</option>
                  </select>
                </div>

                <div>
                  <label className="text-slate-300 font-medium block mb-1">3. Business Criticality</label>
                  <select
                    value={criticality}
                    onChange={(e) => setCriticality(e.target.value as any)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-slate-100 focus:outline-none focus:border-cyan-500"
                  >
                    <option value="Mission Critical">Mission Critical (RTO &lt; 4 Hours)</option>
                    <option value="High">High Operational Impact</option>
                    <option value="Medium">Medium Operational Impact</option>
                    <option value="Low">Low / Commodity Alternative Available</option>
                  </select>
                </div>
              </div>

              {/* Calculated Tier Output Box */}
              <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 flex items-center justify-between">
                <div>
                  <span className="text-slate-400 block text-[11px]">Calculated Inherent Risk Score:</span>
                  <div className="text-xl font-bold font-mono text-amber-400 tabular-nums">
                    {calculatedInherentRisk} / 25
                  </div>
                </div>

                <div className="text-right">
                  <span className="text-slate-400 block text-[11px]">Assigned Regulatory Tier:</span>
                  <span className={`inline-block font-mono font-bold px-2.5 py-1 rounded text-xs mt-0.5 ${
                    recommendedTier === 'Tier 1' ? 'bg-rose-950 text-rose-300 border border-rose-800' :
                    recommendedTier === 'Tier 2' ? 'bg-amber-950 text-amber-300 border border-amber-800' :
                    'bg-slate-800 text-slate-300 border border-slate-700'
                  }`}>
                    {recommendedTier} (OCC Bulletin 2013-29)
                  </span>
                </div>
              </div>
            </div>
          )}

          {/* STEP 3 */}
          {step === 3 && (
            <div className="space-y-4">
              <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-slate-200 font-semibold">Automated Perimeter Attack Surface Recon</span>
                  <button
                    onClick={handleStartScan}
                    disabled={isScanning}
                    className="px-3 py-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white font-medium flex items-center gap-1.5 cursor-pointer disabled:opacity-60"
                  >
                    {isScanning ? (
                      <>
                        <Loader2 className="w-3.5 h-3.5 animate-spin" />
                        <span>Scanning {domain}...</span>
                      </>
                    ) : (
                      <>
                        <Activity className="w-3.5 h-3.5" />
                        <span>Run Scan</span>
                      </>
                    )}
                  </button>
                </div>

                {scanCompleted ? (
                  <div className="space-y-2 pt-2 border-t border-slate-800 text-xs">
                    <div className="flex items-center justify-between">
                      <span className="text-slate-400">External Posture Score:</span>
                      <span className="font-mono text-cyan-400 font-bold">{simulatedScore} / 100 (Grade B)</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-slate-400">Detected Cloud Host:</span>
                      <span className="font-mono text-slate-200">{detectedHost}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-slate-400">TLS 1.3 / HSTS Status:</span>
                      <span className="text-emerald-400 font-medium">Valid (Let's Encrypt / DigiCert EV)</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-slate-400">DMARC Policy:</span>
                      <span className="text-emerald-400 font-medium">p=reject (Full Anti-Spoofing Active)</span>
                    </div>
                  </div>
                ) : (
                  <p className="text-xs text-slate-400">
                    Click 'Run Scan' to query public DNS, ASN telemetry, and SSL certificate chains for <strong>{domain || 'target domain'}</strong>.
                  </p>
                )}
              </div>

              <div className="p-4 bg-cyan-950/30 border border-cyan-900/60 rounded-xl space-y-1">
                <span className="text-cyan-300 font-semibold block">Automatic Assessment Initiation</span>
                <p className="text-slate-300 text-xs leading-relaxed">
                  Upon onboarding, an initial <strong>{recommendedTier} SIG Lite Assessment</strong> will be created and an invitation sent to <strong>{contactEmail || 'vendor contact'}</strong>.
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="p-4 bg-slate-950 border-t border-slate-800 flex items-center justify-between text-xs">
          {step > 1 ? (
            <button
              onClick={() => setStep((prev) => (prev - 1) as any)}
              className="px-4 py-2 text-slate-300 hover:text-white bg-slate-800 rounded-lg cursor-pointer"
            >
              Back
            </button>
          ) : <div />}

          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-4 py-2 text-slate-400 hover:text-white"
            >
              Cancel
            </button>
            {step < 3 ? (
              <button
                onClick={() => setStep((prev) => (prev + 1) as any)}
                className="px-4 py-2 bg-cyan-600 hover:bg-cyan-500 text-white rounded-lg font-medium flex items-center gap-1 cursor-pointer"
              >
                <span>Continue</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            ) : (
              <button
                onClick={handleCreateVendor}
                className="px-4 py-2 bg-cyan-600 hover:bg-cyan-500 text-white rounded-lg font-medium flex items-center gap-1.5 cursor-pointer shadow-sm"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>Complete Onboarding</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
