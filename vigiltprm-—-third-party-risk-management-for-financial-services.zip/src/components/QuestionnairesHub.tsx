import React, { useState } from 'react';
import { 
  FileCheck2, 
  Search, 
  Filter, 
  ChevronRight, 
  Clock, 
  Percent, 
  Building2, 
  Plus, 
  CheckCircle2, 
  AlertTriangle 
} from 'lucide-react';
import { Vendor, VendorQuestionnaire } from '../types/tprm';

interface QuestionnairesHubProps {
  vendors: Vendor[];
  onOpenQuestionnaire: (q: VendorQuestionnaire) => void;
  onOpenAddVendor: () => void;
}

export const QuestionnairesHub: React.FC<QuestionnairesHubProps> = ({
  vendors,
  onOpenQuestionnaire,
  onOpenAddVendor
}) => {
  const [standardFilter, setStandardFilter] = useState<string>('All');
  const [statusFilter, setStatusFilter] = useState<string>('All');
  const [searchTerm, setSearchTerm] = useState('');

  // Collect all questionnaires from all vendors
  const allQuestionnaires = vendors.flatMap(v => v.questionnaires);

  const filteredQuestionnaires = allQuestionnaires.filter(q => {
    const matchesSearch = 
      q.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      q.vendorName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      q.standard.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesStandard = standardFilter === 'All' || q.standard === standardFilter;
    const matchesStatus = statusFilter === 'All' || q.status === statusFilter;

    return matchesSearch && matchesStandard && matchesStatus;
  });

  return (
    <div className="p-8 space-y-6 max-w-7xl mx-auto">
      {/* Title */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-white flex items-center gap-2">
            <FileCheck2 className="w-5 h-5 text-cyan-400" />
            <span>Security Assessment Engine (SIG / CAIQ / DORA)</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Standardized Information Gathering assessments, domain control scoring, and evidence verification
          </p>
        </div>
      </div>

      {/* KPI strip */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl space-y-1">
          <span className="text-slate-400 text-xs">Total Assessments</span>
          <div className="text-2xl font-bold font-mono text-white tabular-nums">{allQuestionnaires.length}</div>
          <p className="text-[11px] text-slate-400">SIG Lite, CAIQ & DORA templates</p>
        </div>

        <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl space-y-1">
          <span className="text-slate-400 text-xs">Completed & Verified</span>
          <div className="text-2xl font-bold font-mono text-emerald-400 tabular-nums">
            {allQuestionnaires.filter(q => q.status === 'Completed').length}
          </div>
          <p className="text-[11px] text-slate-400">Auditor verified with evidence</p>
        </div>

        <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl space-y-1">
          <span className="text-slate-400 text-xs">Under Analyst Review</span>
          <div className="text-2xl font-bold font-mono text-amber-400 tabular-nums">
            {allQuestionnaires.filter(q => q.status === 'Under Review').length}
          </div>
          <p className="text-[11px] text-slate-400">Aegis Core Banking assessment</p>
        </div>

        <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl space-y-1">
          <span className="text-slate-400 text-xs">Average Fleet Assurance Score</span>
          <div className="text-2xl font-bold font-mono text-cyan-300 tabular-nums">87 / 100</div>
          <p className="text-[11px] text-slate-400">Weighted domain controls</p>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-3">
        <div className="flex flex-col md:flex-row items-center gap-3">
          <div className="relative w-full md:flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search assessment title, standard, or vendor..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg pl-9 pr-4 py-2 text-xs text-slate-100 placeholder-slate-400 focus:outline-none focus:border-cyan-500"
            />
          </div>

          <div className="flex items-center gap-1.5 w-full md:w-auto">
            <span className="text-xs text-slate-400">Standard:</span>
            <select
              value={standardFilter}
              onChange={(e) => setStandardFilter(e.target.value)}
              className="bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-cyan-500 cursor-pointer"
            >
              <option value="All">All Standards</option>
              <option value="SIG Lite">SIG Lite</option>
              <option value="SIG Complete">SIG Complete</option>
              <option value="CSA CAIQ v4">CSA CAIQ v4</option>
              <option value="DORA ICT Third-Party">DORA ICT Third-Party</option>
            </select>
          </div>

          <div className="flex items-center gap-1.5 w-full md:w-auto">
            <span className="text-xs text-slate-400">Status:</span>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-cyan-500 cursor-pointer"
            >
              <option value="All">All Statuses</option>
              <option value="Completed">Completed</option>
              <option value="Under Review">Under Review</option>
              <option value="In Progress">In Progress</option>
              <option value="Sent to Vendor">Sent to Vendor</option>
            </select>
          </div>
        </div>
      </div>

      {/* Questionnaires Grid */}
      <div className="space-y-3">
        {filteredQuestionnaires.length === 0 ? (
          <div className="py-16 text-center text-slate-400 bg-slate-900 border border-slate-800 rounded-xl space-y-2">
            <FileCheck2 className="w-8 h-8 text-slate-400 mx-auto" />
            <p className="text-xs font-medium text-slate-200">No assessments matching criteria</p>
          </div>
        ) : (
          filteredQuestionnaires.map(q => (
            <div
              key={q.id}
              className="p-5 rounded-xl bg-slate-900 border border-slate-800 hover:border-slate-700 transition-colors flex flex-col md:flex-row md:items-center justify-between gap-4"
            >
              <div className="space-y-1.5">
                <div className="flex items-center gap-2 text-xs">
                  <span className="font-mono text-cyan-400 font-bold bg-cyan-950/60 px-2 py-0.5 rounded border border-cyan-800/60">
                    {q.standard}
                  </span>
                  <span className="font-semibold text-slate-200">{q.vendorName}</span>
                  <span className="text-slate-400" aria-hidden="true">·</span>
                  <span className="text-slate-400">Due: {q.dueDate}</span>
                  <span className="text-slate-400" aria-hidden="true">·</span>
                  <span className={`font-medium ${
                    q.status === 'Completed' ? 'text-emerald-400' :
                    q.status === 'Under Review' ? 'text-amber-400' : 'text-blue-400'
                  }`}>
                    {q.status}
                  </span>
                </div>

                <h3 className="text-sm font-semibold text-white">{q.title}</h3>
                <div className="flex items-center gap-4 text-xs text-slate-400 pt-1">
                  <span>Questions: <strong className="text-slate-200 font-mono">{q.sections.reduce((a, s) => a + s.questions.length, 0)} Controls</strong></span>
                  <span aria-hidden="true">·</span>
                  <span>Completion: <strong className="text-slate-200 font-mono">{q.completionRate}%</strong></span>
                  <span aria-hidden="true">·</span>
                  <span>Assurance Score: <strong className="text-cyan-400 font-mono">{q.overallScore} / 100</strong></span>
                </div>
              </div>

              <div className="flex items-center gap-3 shrink-0">
                <button
                  onClick={() => onOpenQuestionnaire(q)}
                  className="px-4 py-2 text-xs font-medium text-white bg-cyan-600 hover:bg-cyan-500 rounded-lg transition-colors cursor-pointer flex items-center gap-1.5 shadow-sm"
                >
                  <span>Open Interactive Engine</span>
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
