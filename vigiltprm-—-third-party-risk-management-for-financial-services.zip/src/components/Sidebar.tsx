import React from 'react';
import { 
  ShieldCheck, 
  LayoutDashboard, 
  Building2, 
  FileCheck2, 
  Activity, 
  Network, 
  AlertTriangle, 
  FileText,
  Building,
  UserCheck
} from 'lucide-react';
import { InstitutionProfile } from '../types/tprm';

interface SidebarProps {
  currentTab: string;
  setCurrentTab: (tab: string) => void;
  institution: InstitutionProfile;
  activeAlertsCount: number;
  openFindingsCount: number;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentTab,
  setCurrentTab,
  institution,
  activeAlertsCount,
  openFindingsCount,
}) => {
  const navItems = [
    { id: 'dashboard', label: 'Executive Overview', icon: LayoutDashboard },
    { id: 'vendors', label: 'Vendor Inventory & Tiers', icon: Building2 },
    { id: 'questionnaires', label: 'Security Questionnaires', icon: FileCheck2 },
    { id: 'monitoring', label: 'Continuous Monitoring', icon: Activity, badge: activeAlertsCount },
    { id: 'concentration', label: 'Concentration & 4th Party', icon: Network },
    { id: 'remediation', label: 'Remediation & CAP', icon: AlertTriangle, badge: openFindingsCount },
    { id: 'reports', label: 'Regulatory Audit Pack', icon: FileText },
  ];

  return (
    <aside className="w-64 bg-slate-900 border-r border-slate-800 flex flex-col shrink-0 select-none">
      {/* Brand Header */}
      <div className="p-5 border-b border-slate-800 flex items-center gap-3">
        <div className="w-9 h-9 rounded-lg bg-cyan-950 border border-cyan-800 flex items-center justify-center text-cyan-400 font-bold shadow-inner">
          <ShieldCheck className="w-5 h-5 text-cyan-400" />
        </div>
        <div>
          <h1 className="text-base font-semibold tracking-tight text-white flex items-center gap-1.5">
            VigilTPRM
          </h1>
          <p className="text-xs text-slate-400">Financial Risk Assurance</p>
        </div>
      </div>

      {/* Institution Context Card */}
      <div className="px-4 py-3 mx-3 my-3 bg-slate-950/70 border border-slate-800/80 rounded-lg">
        <div className="flex items-center gap-2 mb-1 text-slate-400">
          <Building className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
          <span className="text-xs font-medium text-slate-300 truncate">{institution.name}</span>
        </div>
        <p className="text-[11px] text-slate-400 leading-tight">Charter: {institution.charterType}</p>
        <div className="mt-2 pt-2 border-t border-slate-800/60 flex items-center justify-between text-[11px] text-slate-400">
          <span>Regulators</span>
          <span className="font-mono text-slate-300 font-medium">OCC · FRB · DORA</span>
        </div>
      </div>

      {/* Navigation Links */}
      <nav className="flex-1 px-3 space-y-1 overflow-y-auto pt-1">
        <div className="px-3 pb-2 text-[10px] font-semibold uppercase tracking-wider text-slate-400">
          Risk Management
        </div>
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setCurrentTab(item.id)}
              className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-xs font-medium transition-all ${
                isActive
                  ? 'bg-cyan-950/60 text-cyan-300 border border-cyan-800/50 shadow-sm'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <div className="flex items-center gap-3">
                <Icon className={`w-4 h-4 ${isActive ? 'text-cyan-400' : 'text-slate-400'}`} />
                <span>{item.label}</span>
              </div>
              {item.badge !== undefined && item.badge > 0 && (
                <span className={`px-2 py-0.5 text-[10px] font-mono font-medium rounded ${
                  isActive ? 'bg-cyan-500/20 text-cyan-300' : 'bg-slate-800 text-slate-300'
                }`}>
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </nav>

      {/* Current Analyst Profile */}
      <div className="p-4 border-t border-slate-800 bg-slate-950/40">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center text-xs font-semibold text-cyan-400">
            ER
          </div>
          <div className="overflow-hidden">
            <p className="text-xs font-medium text-slate-200 truncate">Elena Rostova, CISM</p>
            <p className="text-[11px] text-slate-400 truncate">VP, Third-Party Risk</p>
          </div>
        </div>
        <div className="mt-2.5 flex items-center gap-1.5 text-[11px] text-emerald-400">
          <UserCheck className="w-3 h-3 shrink-0" />
          <span>Supervisory Clearance Active</span>
        </div>
      </div>
    </aside>
  );
};
