import React, { useState } from 'react';
import { 
  X, 
  ShieldCheck, 
  AlertTriangle, 
  FileText, 
  Network, 
  Activity, 
  ExternalLink, 
  CheckCircle2, 
  AlertOctagon, 
  Calendar, 
  Building2, 
  Lock,
  Download,
  Send,
  Plus
} from 'lucide-react';
import { Vendor, VendorQuestionnaire, Finding } from '../types/tprm';

interface VendorDetailModalProps {
  vendor: Vendor;
  onClose: () => void;
  onOpenQuestionnaire: (questionnaire: VendorQuestionnaire) => void;
  onResolveFinding: (findingId: string) => void;
  onLaunchNewQuestionnaire: (vendorId: string, standard: string) => void;
}

export const VendorDetailModal: React.FC<VendorDetailModalProps> = ({
  vendor,
  onClose,
  onOpenQuestionnaire,
  onResolveFinding,
  onLaunchNewQuestionnaire
}) => {
  const [activeTab, setActiveTab] = useState<'scorecard' | 'questionnaires' | 'findings' | 'fourthParty' | 'documents'>('scorecard');
  const [showLaunchModal, setShowLaunchModal] = useState(false);
  const [selectedStandard, setSelectedStandard] = useState<'SIG Lite' | 'SIG Complete' | 'CSA CAIQ v4' | 'DORA ICT Third-Party'>('SIG Lite');

  const vectorDetails = [
    { label: 'Network Security', score: vendor.vectorScores.networkSecurity, desc: 'TLS 1.3 enforcement, port hygiene, firewall configs' },
    { label: 'Patching Cadence', score: vendor.vectorScores.patchCadence, desc: 'Mean-time-to-remediate (MTTR) for known CVEs' },
    { label: 'Application Security', score: vendor.vectorScores.applicationSecurity, desc: 'WAF presence, CSP headers, HSTS preloading' },
    { label: 'DNS & Email Hygiene', score: vendor.vectorScores.dnsEmailHygiene, desc: 'SPF, DKIM, and DMARC reject policies' },
    { label: 'Dark Web Exposure', score: vendor.vectorScores.darkWebExposure, desc: 'Compromised corporate credentials in breach dumps' },
    { label: 'Endpoint Hygiene', score: vendor.vectorScores.endpointHygiene, desc: 'EDR telemetry, OS patching, browser compliance' },
    { label: 'Compliance Attestation', score: vendor.vectorScores.complianceAttestation, desc: 'Active SOC 2 Type II, ISO 27001, and SIG coverage' },
  ];

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-5xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden my-auto">
        {/* Modal Header */}
        <div className="p-6 bg-slate-950 border-b border-slate-800 flex items-start justify-between">
          <div className="space-y-1.5">
            <div className="flex items-center gap-3">
              <h2 className="text-xl font-bold text-white tracking-tight">{vendor.name}</h2>
              <span className={`text-xs font-mono font-semibold px-2 py-0.5 rounded ${
                vendor.tier === 'Tier 1' ? 'bg-rose-950/80 text-rose-300 border border-rose-800' :
                vendor.tier === 'Tier 2' ? 'bg-amber-950/80 text-amber-300 border border-amber-800' :
                'bg-slate-800 text-slate-300 border border-slate-700'
              }`}>
                {vendor.tier}
              </span>
              <span className="text-xs text-slate-400 font-mono">[{vendor.domain}]</span>
              <span className={`text-xs font-medium px-2 py-0.5 rounded ${
                vendor.status === 'Active' ? 'text-emerald-400 bg-emerald-950/40 border border-emerald-900' :
                'text-amber-400 bg-amber-950/40 border border-amber-900'
              }`}>
                {vendor.status}
              </span>
            </div>
            <p className="text-xs text-slate-400 max-w-3xl leading-relaxed">{vendor.description}</p>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Quick KPI Bar */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-3 p-4 bg-slate-900/60 border-b border-slate-800 text-xs">
          <div className="p-2.5 rounded-lg bg-slate-950/40 border border-slate-800/80">
            <span className="text-slate-400 block text-[11px]">External Posture</span>
            <div className="flex items-baseline gap-1.5 mt-0.5">
              <span className="text-base font-bold text-white font-mono">{vendor.securityScore}/100</span>
              <span className={`font-mono font-bold ${
                vendor.scoreGrade === 'A' ? 'text-emerald-400' :
                vendor.scoreGrade === 'B' ? 'text-cyan-400' :
                vendor.scoreGrade === 'C' ? 'text-amber-400' : 'text-rose-400'
              }`}>
                (Grade {vendor.scoreGrade})
              </span>
            </div>
          </div>

          <div className="p-2.5 rounded-lg bg-slate-950/40 border border-slate-800/80">
            <span className="text-slate-400 block text-[11px]">Risk (Inherent → Residual)</span>
            <div className="flex items-baseline gap-1 mt-0.5 font-mono">
              <span className="text-amber-400 font-bold">{vendor.inherentRiskScore}</span>
              <span className="text-slate-500">→</span>
              <span className={`text-base font-bold ${
                vendor.residualRiskScore > 12 ? 'text-rose-400' :
                vendor.residualRiskScore > 8 ? 'text-amber-400' : 'text-emerald-400'
              }`}>
                {vendor.residualRiskScore}/25
              </span>
            </div>
          </div>

          <div className="p-2.5 rounded-lg bg-slate-950/40 border border-slate-800/80">
            <span className="text-slate-400 block text-[11px]">Annual Spend & Renewal</span>
            <div className="mt-0.5 font-mono text-slate-200">
              ${(vendor.annualSpendUsd / 1000).toLocaleString()}k USD
              <span className="text-slate-400 block text-[10px] font-sans">Renews: {vendor.contractRenewalDate}</span>
            </div>
          </div>

          <div className="p-2.5 rounded-lg bg-slate-950/40 border border-slate-800/80">
            <span className="text-slate-400 block text-[11px]">Business Owner</span>
            <div className="mt-0.5 text-slate-200 truncate font-medium">
              {vendor.businessOwner}
            </div>
            <span className="text-[10px] text-slate-400">Analyst: {vendor.tprAnalyst}</span>
          </div>

          <div className="p-2.5 rounded-lg bg-slate-950/40 border border-slate-800/80">
            <span className="text-slate-400 block text-[11px]">Hosting Infrastructure</span>
            <div className="mt-0.5 text-slate-200 truncate font-mono text-[11px]">
              {vendor.hostingLocation}
            </div>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-1 px-6 border-b border-slate-800 bg-slate-950/80 text-xs">
          {[
            { id: 'scorecard', label: 'Security Scorecard & Vectors', icon: Activity },
            { id: 'questionnaires', label: `Questionnaires (${vendor.questionnaires.length})`, icon: FileText },
            { id: 'findings', label: `Deficiencies & CAP (${vendor.activeFindingsCount.critical + vendor.activeFindingsCount.high + vendor.activeFindingsCount.medium})`, icon: AlertTriangle },
            { id: 'fourthParty', label: `4th Party Supply Chain (${vendor.fourthParties.length})`, icon: Network },
            { id: 'documents', label: `SOC 2 & Audit Vault (${vendor.documents.length})`, icon: ShieldCheck },
          ].map(tab => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center gap-2 py-3 px-3.5 border-b-2 font-medium transition-colors cursor-pointer ${
                  isActive
                    ? 'border-cyan-500 text-cyan-400'
                    : 'border-transparent text-slate-400 hover:text-slate-200'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Tab Content Area */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* TAB 1: SCORECARD & VECTORS */}
          {activeTab === 'scorecard' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <div>
                  <h3 className="text-sm font-semibold text-white">External Attack Surface Security Vectors</h3>
                  <p className="text-xs text-slate-400 mt-0.5">Continuous automated telemetry evaluated every 24 hours against internet-facing assets</p>
                </div>
                <div className="text-right">
                  <span className="text-xs font-mono text-cyan-400">Credit Score: {vendor.creditStyleScore} / 850</span>
                  <span className="text-[11px] text-slate-400 block font-mono">
                    30-Day Trend: {vendor.scoreTrend30d >= 0 ? `+${vendor.scoreTrend30d}` : vendor.scoreTrend30d} pts
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {vectorDetails.map(vec => (
                  <div key={vec.label} className="p-4 bg-slate-950/60 border border-slate-800 rounded-xl space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-semibold text-slate-200">{vec.label}</span>
                      <span className={`font-mono text-xs font-bold tabular-nums ${
                        vec.score >= 90 ? 'text-emerald-400' :
                        vec.score >= 80 ? 'text-cyan-400' :
                        vec.score >= 70 ? 'text-amber-400' : 'text-rose-400'
                      }`}>
                        {vec.score} / 100
                      </span>
                    </div>
                    <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
                      <div
                        className={`h-full rounded-full ${
                          vec.score >= 90 ? 'bg-emerald-500' :
                          vec.score >= 80 ? 'bg-cyan-500' :
                          vec.score >= 70 ? 'bg-amber-500' : 'bg-rose-500'
                        }`}
                        style={{ width: `${vec.score}%` }}
                      />
                    </div>
                    <p className="text-[11px] text-slate-400 leading-tight">{vec.desc}</p>
                  </div>
                ))}
              </div>

              {/* Data Classifications & Regulatory Tags */}
              <div className="p-4 bg-slate-950/40 border border-slate-800 rounded-xl space-y-3">
                <h4 className="text-xs font-semibold text-slate-200 uppercase tracking-wider">Applicable Regulatory Frameworks & Data Scope</h4>
                <div className="flex flex-wrap gap-2">
                  {vendor.applicableFrameworks.map(fw => (
                    <span key={fw} className="text-xs px-2.5 py-1 rounded bg-cyan-950/60 border border-cyan-800/60 text-cyan-300 font-mono">
                      {fw}
                    </span>
                  ))}
                  {vendor.dataClassifications.map(dc => (
                    <span key={dc} className="text-xs px-2.5 py-1 rounded bg-slate-800 border border-slate-700 text-slate-300 font-mono">
                      Scope: {dc}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: QUESTIONNAIRES */}
          {activeTab === 'questionnaires' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <div>
                  <h3 className="text-sm font-semibold text-white">Vendor Security Assessments</h3>
                  <p className="text-xs text-slate-400 mt-0.5">SIG Lite, CSA CAIQ, and DORA ICT third-party questionnaires</p>
                </div>
                <button
                  onClick={() => setShowLaunchModal(true)}
                  className="px-3 py-1.5 text-xs font-medium text-white bg-cyan-600 hover:bg-cyan-500 rounded-lg shadow-sm transition-colors cursor-pointer flex items-center gap-1.5"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Launch Assessment</span>
                </button>
              </div>

              {vendor.questionnaires.length === 0 ? (
                <div className="py-12 text-center text-slate-400 border border-dashed border-slate-800 rounded-xl space-y-3">
                  <FileText className="w-8 h-8 text-slate-400 mx-auto" />
                  <p className="text-xs">No formal questionnaires on file for this vendor.</p>
                  <button
                    onClick={() => setShowLaunchModal(true)}
                    className="px-3 py-1.5 text-xs font-medium text-cyan-400 hover:text-cyan-300 bg-slate-800 rounded-lg border border-slate-700 cursor-pointer"
                  >
                    Send SIG Lite Assessment
                  </button>
                </div>
              ) : (
                <div className="space-y-3">
                  {vendor.questionnaires.map(q => (
                    <div 
                      key={q.id}
                      className="p-5 rounded-xl bg-slate-950/70 border border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-4"
                    >
                      <div className="space-y-1">
                        <div className="flex items-center gap-2 text-xs">
                          <span className="font-mono text-cyan-400 font-semibold">{q.standard}</span>
                          <span className="text-slate-400" aria-hidden="true">·</span>
                          <span className="text-slate-400">Due: {q.dueDate}</span>
                          <span className="text-slate-400" aria-hidden="true">·</span>
                          <span className={`font-medium ${
                            q.status === 'Completed' ? 'text-emerald-400' :
                            q.status === 'Under Review' ? 'text-amber-400' : 'text-blue-400'
                          }`}>
                            {q.status}
                          </span>
                        </div>
                        <h4 className="text-sm font-semibold text-slate-100">{q.title}</h4>
                        <div className="flex items-center gap-4 text-xs text-slate-400 pt-1">
                          <span>Completion: <strong className="text-slate-200 font-mono">{q.completionRate}%</strong></span>
                          <span>Assurance Score: <strong className="text-cyan-400 font-mono">{q.overallScore} / 100</strong></span>
                        </div>
                      </div>

                      <div className="flex items-center gap-3">
                        <button
                          onClick={() => onOpenQuestionnaire(q)}
                          className="px-4 py-2 text-xs font-medium text-white bg-cyan-600 hover:bg-cyan-500 rounded-lg transition-colors cursor-pointer flex items-center gap-1.5"
                        >
                          <span>Open Review Engine</span>
                          <ExternalLink className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 3: FINDINGS & CAP */}
          {activeTab === 'findings' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <div>
                  <h3 className="text-sm font-semibold text-white">Deficiencies & Corrective Action Plans (CAP)</h3>
                  <p className="text-xs text-slate-400 mt-0.5">Audit findings, continuous monitoring alerts, and SLA remediation countdowns</p>
                </div>
              </div>

              {vendor.activeFindingsCount.critical === 0 && 
               vendor.activeFindingsCount.high === 0 && 
               vendor.activeFindingsCount.medium === 0 ? (
                <div className="py-10 text-center text-slate-400 border border-slate-800 rounded-xl space-y-2">
                  <CheckCircle2 className="w-8 h-8 text-emerald-400 mx-auto" />
                  <p className="text-xs font-medium text-slate-200">Zero Outstanding Deficiencies</p>
                  <p className="text-[11px] text-slate-400">All vendor controls are within acceptable bank risk appetite thresholds.</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {/* Finding Item Mocked for this vendor */}
                  <div className="p-4 rounded-xl bg-slate-950/80 border border-rose-900/40 space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-rose-950 text-rose-300 border border-rose-800">
                          CRITICAL FINDING
                        </span>
                        <span className="text-xs text-slate-400 font-mono">SLA Remaining: 2 Days</span>
                      </div>
                      <span className="text-xs text-amber-400 font-medium">In Remediation</span>
                    </div>

                    <div>
                      <h4 className="text-sm font-semibold text-slate-100">
                        {vendor.name === 'Aegis Core Banking Systems' 
                          ? 'Unpatched Critical CVE-2024-3400 on Perimeter Gateway (CVSS 10.0)' 
                          : 'Delayed Access De-provisioning Audit Exceptions'}
                      </h4>
                      <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                        {vendor.name === 'Aegis Core Banking Systems'
                          ? 'Active perimeter scanning identified unpatched gateway software vulnerable to unauthenticated remote code execution.'
                          : 'SIG assessment verification revealed 2 former employees retained SSO access for 72 hours post-termination.'}
                      </p>
                    </div>

                    <div className="p-3 rounded-lg bg-slate-900/80 border border-slate-800 text-xs space-y-1">
                      <span className="text-slate-400 block font-medium">Vendor Corrective Action Plan:</span>
                      <p className="text-slate-200">
                        {vendor.name === 'Aegis Core Banking Systems'
                          ? 'Deploy vendor hotfix firmware HF-9844 during maintenance window tonight at 02:00 UTC.'
                          : 'Implement automated SCIM de-provisioning trigger between Workday HRIS and Okta directory.'}
                      </p>
                      <p className="text-[11px] text-emerald-400 pt-1">
                        Compensating Control: WAF virtual patching rule active on Cloudflare edge.
                      </p>
                    </div>

                    <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800/60">
                      <button
                        onClick={() => onResolveFinding('fnd-101')}
                        className="px-3 py-1.5 text-xs font-medium text-emerald-300 hover:text-white bg-emerald-950/60 hover:bg-emerald-900 border border-emerald-800/80 rounded transition-colors cursor-pointer"
                      >
                        Verify & Mark Resolved
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 4: 4TH PARTY SUPPLY CHAIN */}
          {activeTab === 'fourthParty' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <div>
                  <h3 className="text-sm font-semibold text-white">4th-Party Dependencies & Sub-processors</h3>
                  <p className="text-xs text-slate-400 mt-0.5">Critical supply chain concentration mapping mandated by DORA Article 28</p>
                </div>
                <span className="text-xs font-mono text-cyan-400">Total Dependencies: {vendor.fourthParties.length}</span>
              </div>

              <div className="space-y-3">
                {vendor.fourthParties.map((fp, idx) => (
                  <div key={idx} className="p-4 rounded-xl bg-slate-950/60 border border-slate-800 space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-semibold text-slate-100">{fp.name}</span>
                        <span className="text-xs text-slate-400 font-mono">[{fp.provider}]</span>
                      </div>
                      <span className={`text-[11px] font-mono px-2 py-0.5 rounded font-medium ${
                        fp.riskLevel === 'High' ? 'bg-rose-950 text-rose-300 border border-rose-800' :
                        fp.riskLevel === 'Medium' ? 'bg-amber-950 text-amber-300 border border-amber-800' :
                        'bg-slate-800 text-slate-300 border border-slate-700'
                      }`}>
                        {fp.riskLevel} Risk
                      </span>
                    </div>

                    <div className="flex items-center gap-4 text-xs text-slate-400">
                      <span>Category: <strong className="text-slate-300">{fp.category}</strong></span>
                      <span aria-hidden="true">·</span>
                      <span>Region: <strong className="text-slate-300">{fp.region}</strong></span>
                    </div>

                    <p className="text-xs text-slate-400 bg-slate-900/60 p-2.5 rounded-lg border border-slate-800/80">
                      {fp.notes}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 5: DOCUMENTS & SOC 2 VAULT */}
          {activeTab === 'documents' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <div>
                  <h3 className="text-sm font-semibold text-white">Compliance Attestations & Audit Reports</h3>
                  <p className="text-xs text-slate-400 mt-0.5">Independent auditor opinions (SOC 2, ISO 27001, Pen Tests, Bridge Letters)</p>
                </div>
              </div>

              {vendor.documents.length === 0 ? (
                <div className="py-12 text-center text-slate-400 border border-dashed border-slate-800 rounded-xl space-y-2">
                  <Lock className="w-8 h-8 text-slate-400 mx-auto" />
                  <p className="text-xs">No compliance certificates currently indexed in the vault.</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {vendor.documents.map(doc => (
                    <div key={doc.id} className="p-4 rounded-xl bg-slate-950/60 border border-slate-800 flex items-center justify-between">
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-mono font-semibold text-cyan-400">{doc.type}</span>
                          <span className="text-slate-400" aria-hidden="true">·</span>
                          <span className={`text-[11px] font-medium ${
                            doc.status === 'Valid' ? 'text-emerald-400' :
                            doc.status === 'Expiring Soon' ? 'text-amber-400' : 'text-rose-400'
                          }`}>
                            {doc.status}
                          </span>
                        </div>
                        <h4 className="text-xs font-semibold text-slate-100">{doc.name}</h4>
                        <div className="flex items-center gap-4 text-[11px] text-slate-400">
                          <span>Auditor: <strong className="text-slate-300">{doc.auditor}</strong></span>
                          <span aria-hidden="true">·</span>
                          <span>Coverage: {doc.periodStart} to {doc.periodEnd}</span>
                          <span aria-hidden="true">·</span>
                          <span>Size: {doc.fileSize}</span>
                        </div>
                        {doc.qualifiedOpinion && (
                          <p className="text-[11px] text-amber-300 bg-amber-950/30 border border-amber-900/40 p-1.5 rounded mt-1">
                            Auditor Exception: {doc.exceptionsNoted}
                          </p>
                        )}
                      </div>

                      <button
                        onClick={() => {}}
                        className="px-3 py-1.5 text-xs font-medium text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-lg border border-slate-700 transition-colors flex items-center gap-1.5 cursor-pointer"
                      >
                        <Download className="w-3.5 h-3.5" />
                        <span>Download</span>
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-4 bg-slate-950 border-t border-slate-800 flex items-center justify-between text-xs">
          <div className="text-slate-400 font-mono">
            Vendor ID: {vendor.id} · OCC Tier: {vendor.tier}
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-lg border border-slate-700 cursor-pointer"
            >
              Close Dossier
            </button>
          </div>
        </div>
      </div>

      {/* Launch New Questionnaire Sub-Modal */}
      {showLaunchModal && (
        <div className="fixed inset-0 z-60 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 max-w-md w-full space-y-4 shadow-2xl">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <h3 className="text-sm font-bold text-white">Launch Vendor Security Assessment</h3>
              <button onClick={() => setShowLaunchModal(false)} className="text-slate-400 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-xs text-slate-300">
              Select the standard assessment to dispatch to <strong>{vendor.contactEmail}</strong>:
            </p>

            <div className="space-y-2">
              {[
                { id: 'SIG Lite', label: 'SIG Lite (Standardized Information Gathering)', desc: 'Standard 55 controls for SaaS and operational providers.' },
                { id: 'SIG Complete', label: 'SIG Complete (Comprehensive Financial)', desc: 'Deep dive 180+ controls for Tier 1 core banking systems.' },
                { id: 'CSA CAIQ v4', label: 'CSA CAIQ v4 (Cloud Security Alliance)', desc: 'Cloud architecture, tenant isolation, and hypervisor controls.' },
                { id: 'DORA ICT Third-Party', label: 'DORA ICT Resilience Assessment', desc: 'EU Digital Operational Resilience Act Articles 28-30.' },
              ].map(opt => (
                <label 
                  key={opt.id}
                  className={`flex items-start gap-3 p-3 rounded-lg border cursor-pointer transition-colors ${
                    selectedStandard === opt.id ? 'bg-cyan-950/60 border-cyan-700 text-white' : 'bg-slate-950/40 border-slate-800 text-slate-300'
                  }`}
                >
                  <input
                    type="radio"
                    name="assessment-standard"
                    checked={selectedStandard === opt.id}
                    onChange={() => setSelectedStandard(opt.id as any)}
                    className="mt-0.5 text-cyan-500"
                  />
                  <div>
                    <div className="text-xs font-semibold">{opt.label}</div>
                    <div className="text-[11px] text-slate-400 mt-0.5">{opt.desc}</div>
                  </div>
                </label>
              ))}
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-800">
              <button
                onClick={() => setShowLaunchModal(false)}
                className="px-3 py-1.5 text-xs text-slate-400 hover:text-white"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  onLaunchNewQuestionnaire(vendor.id, selectedStandard);
                  setShowLaunchModal(false);
                }}
                className="px-4 py-1.5 text-xs font-medium text-white bg-cyan-600 hover:bg-cyan-500 rounded-lg flex items-center gap-1.5"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Dispatch to Vendor</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
