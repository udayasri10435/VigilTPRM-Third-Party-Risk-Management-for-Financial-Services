import React, { useState, useMemo } from 'react';
import { 
  Activity, 
  AlertOctagon, 
  ShieldAlert, 
  Search, 
  Filter, 
  RefreshCw, 
  ArrowUpRight, 
  CheckCircle2, 
  Clock, 
  Globe, 
  Key, 
  Mail, 
  Server,
  FileWarning
} from 'lucide-react';
import { MonitoringAlert, Vendor } from '../types/tprm';

interface ContinuousMonitoringProps {
  alerts: MonitoringAlert[];
  vendors: Vendor[];
  onAcknowledgeAlert: (alertId: string) => void;
  onRequestRemediation: (alert: MonitoringAlert) => void;
  onRunTelemetryScan: () => void;
  isScanning: boolean;
}

export const ContinuousMonitoring: React.FC<ContinuousMonitoringProps> = ({
  alerts,
  vendors,
  onAcknowledgeAlert,
  onRequestRemediation,
  onRunTelemetryScan,
  isScanning
}) => {
  const [severityFilter, setSeverityFilter] = useState<'All' | 'Critical' | 'High' | 'Medium' | 'Low'>('All');
  const [categoryFilter, setCategoryFilter] = useState<string>('All');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedAlert, setSelectedAlert] = useState<MonitoringAlert | null>(null);

  const filteredAlerts = useMemo(() => {
    return alerts.filter(alert => {
      const matchesSearch = 
        alert.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        alert.vendorName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        alert.detail.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (alert.targetAsset && alert.targetAsset.toLowerCase().includes(searchTerm.toLowerCase()));

      const matchesSeverity = severityFilter === 'All' || alert.severity === severityFilter;
      const matchesCategory = categoryFilter === 'All' || alert.category === categoryFilter;

      return matchesSearch && matchesSeverity && matchesCategory;
    });
  }, [alerts, searchTerm, severityFilter, categoryFilter]);

  // Aggregate stats
  const criticalCount = alerts.filter(a => a.severity === 'Critical').length;
  const highCount = alerts.filter(a => a.severity === 'High').length;
  const totalMonitoredEndpoints = 1420;

  return (
    <div className="p-8 space-y-6 max-w-7xl mx-auto">
      {/* Header Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-white flex items-center gap-2">
            <Activity className="w-5 h-5 text-cyan-400" />
            <span>Continuous Attack Surface Monitoring & Threat Radar</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            24/7 non-intrusive external telemetry monitoring perimeter vulnerabilities, SSL validity, DNS health, and breach intelligence
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={onRunTelemetryScan}
            disabled={isScanning}
            className="flex items-center gap-2 px-3.5 py-1.5 text-xs font-medium text-white bg-cyan-600 hover:bg-cyan-500 rounded-lg shadow-sm transition-colors cursor-pointer disabled:opacity-60"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isScanning ? 'animate-spin' : ''}`} />
            <span>{isScanning ? 'Executing Recon Scan...' : 'Trigger Immediate Fleet Scan'}</span>
          </button>
        </div>
      </div>

      {/* Telemetry Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl space-y-1">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>Critical Severity Events</span>
            <AlertOctagon className="w-4 h-4 text-rose-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-rose-400 tabular-nums">{criticalCount}</div>
          <p className="text-[11px] text-slate-400">Immediate action required under OCC SLA</p>
        </div>

        <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl space-y-1">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>High Severity Events</span>
            <ShieldAlert className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-amber-400 tabular-nums">{highCount}</div>
          <p className="text-[11px] text-slate-400">30-day remediation countdown active</p>
        </div>

        <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl space-y-1">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>Active Monitored Perimeter</span>
            <Server className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-white tabular-nums">{totalMonitoredEndpoints}</div>
          <p className="text-[11px] text-slate-400">Hostnames, ASN gateways & APIs</p>
        </div>

        <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl space-y-1">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>Dark Web Credentials</span>
            <Key className="w-4 h-4 text-blue-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-cyan-300 tabular-nums">4 Matches</div>
          <p className="text-[11px] text-slate-400">Synapse Payments (all MFA verified)</p>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-3">
        <div className="flex flex-col md:flex-row items-center gap-3">
          <div className="relative w-full md:flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search alert by CVE, title, vendor, or affected asset..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg pl-9 pr-4 py-2 text-xs text-slate-100 placeholder-slate-400 focus:outline-none focus:border-cyan-500"
            />
          </div>

          {/* Severity Segmented Filter */}
          <div className="flex items-center gap-1.5 w-full md:w-auto">
            <span className="text-xs text-slate-400">Severity:</span>
            <div className="flex items-center gap-1 p-1 bg-slate-950 border border-slate-800 rounded-lg text-xs">
              {(['All', 'Critical', 'High', 'Medium', 'Low'] as const).map(sev => (
                <button
                  key={sev}
                  onClick={() => setSeverityFilter(sev)}
                  className={`px-2.5 py-1 rounded text-xs font-medium transition-colors cursor-pointer ${
                    severityFilter === sev ? 'bg-cyan-600 text-white' : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {sev}
                </button>
              ))}
            </div>
          </div>

          {/* Category Dropdown */}
          <div className="flex items-center gap-1.5 w-full md:w-auto">
            <span className="text-xs text-slate-400">Category:</span>
            <select
              value={categoryFilter}
              onChange={(e) => setCategoryFilter(e.target.value)}
              className="bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-cyan-500 cursor-pointer"
            >
              <option value="All">All Categories</option>
              <option value="Vulnerability">Perimeter Vulnerabilities</option>
              <option value="Certificate">Certificate & TLS</option>
              <option value="Email Hygiene">DNS & Email Hygiene</option>
              <option value="Breach / Dark Web">Dark Web & Leaks</option>
              <option value="Regulatory">Regulatory & DORA</option>
            </select>
          </div>
        </div>
      </div>

      {/* Live Alerts Feed List */}
      <div className="space-y-3">
        {filteredAlerts.length === 0 ? (
          <div className="py-16 text-center text-slate-400 bg-slate-900 border border-slate-800 rounded-xl space-y-2">
            <CheckCircle2 className="w-8 h-8 text-emerald-400 mx-auto" />
            <p className="text-xs font-medium text-slate-200">No active alerts matching criteria</p>
            <p className="text-[11px] text-slate-400">All vendor perimeters are operating within baseline tolerances.</p>
          </div>
        ) : (
          filteredAlerts.map(alert => (
            <div
              key={alert.id}
              className={`p-5 rounded-xl border transition-all ${
                alert.severity === 'Critical'
                  ? 'bg-slate-900/90 border-rose-900/70 shadow-sm shadow-rose-950/20'
                  : alert.severity === 'High'
                  ? 'bg-slate-900/90 border-amber-900/60'
                  : 'bg-slate-900 border-slate-800'
              }`}
            >
              <div className="flex flex-col md:flex-row md:items-start justify-between gap-4">
                <div className="space-y-2 flex-1">
                  <div className="flex items-center gap-2 text-xs">
                    <span className={`font-mono font-bold text-[11px] px-2 py-0.5 rounded ${
                      alert.severity === 'Critical' ? 'bg-rose-950 text-rose-300 border border-rose-800' :
                      alert.severity === 'High' ? 'bg-amber-950 text-amber-300 border border-amber-800' :
                      'bg-slate-800 text-slate-300'
                    }`}>
                      {alert.severity.toUpperCase()}
                    </span>
                    <span className="font-semibold text-slate-100">{alert.vendorName}</span>
                    <span className="text-slate-400" aria-hidden="true">·</span>
                    <span className="text-slate-400 font-mono text-[11px]">{alert.tier}</span>
                    <span className="text-slate-400" aria-hidden="true">·</span>
                    <span className="text-slate-400 text-[11px] flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {alert.timestamp}
                    </span>
                  </div>

                  <h3 className="text-sm font-semibold text-white">{alert.title}</h3>
                  <p className="text-xs text-slate-300 leading-relaxed">{alert.detail}</p>

                  <div className="flex flex-wrap items-center gap-3 pt-1 text-xs font-mono text-slate-400">
                    {alert.targetAsset && (
                      <span className="flex items-center gap-1 text-slate-300 bg-slate-950 px-2 py-1 rounded border border-slate-800">
                        <Globe className="w-3 h-3 text-cyan-400" />
                        Target: {alert.targetAsset}
                      </span>
                    )}
                    <span className="text-rose-400 bg-rose-950/40 px-2 py-1 rounded border border-rose-900/40">
                      Score Penalty: {alert.impactScoreChange} pts
                    </span>
                    <span className="text-slate-400">
                      Status: <strong className="text-slate-200">{alert.status}</strong>
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0 self-end md:self-start">
                  <button
                    onClick={() => onRequestRemediation(alert)}
                    className="px-3 py-1.5 text-xs font-medium text-white bg-cyan-600 hover:bg-cyan-500 rounded-lg shadow-sm transition-colors cursor-pointer flex items-center gap-1.5"
                  >
                    <FileWarning className="w-3.5 h-3.5" />
                    <span>Create CAP Issue</span>
                  </button>
                  <button
                    onClick={() => onAcknowledgeAlert(alert.id)}
                    className="px-3 py-1.5 text-xs font-medium text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-lg border border-slate-700 transition-colors cursor-pointer"
                  >
                    Acknowledge
                  </button>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
